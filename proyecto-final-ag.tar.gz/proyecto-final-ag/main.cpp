#include <GL/glut.h>
#include <math.h>
#include <SOIL/SOIL.h>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <string>
#include <vector>
#include <SDL2/SDL.h>


#define MOV_ARRIBA      1
#define MOV_ABAJO       2
#define MOV_IZQUIERDA   3
#define MOV_DERECHA     4
using namespace std;

//Matriz para texturas
GLuint texture[0];
//
int E;
char palabra[20];

int IdMain;
int IdSub;

//Sonido
#define RUTA_AUDIO "Sonido/Mario_Tema.wav"

void my_audio_callback(void *userdata, Uint8 *stream, int len);

static Uint8 *audio_pos; // global pointer to the audio buffer to be played
static Uint32 audio_len; // remaining length of the sample we have to play


float validacion=0;
float puntos=0.0;
float vidas=3.0;
float tiempo=13000;

//variables para ocultar letras
int lA, lT, lL, lP, lN,lK, lO, lI, lM, lS, lH, lC,  lE, lY;

//movimiento del lapiz
int flt=30;

//variable para mostrar la imagen a escribir
int rc =0;

/* Constantes para la luz */
const GLfloat light_ambient[]  = { 0.0f, 0.0f, 0.0f, 1.0f };
const GLfloat light_diffuse[]  = { 1.0f, 1.0f, 1.0f, 1.0f };
const GLfloat light_specular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
const GLfloat light_spot_dir[] = { 0.0f, 0.0f, 0.0f};
const GLfloat light_attenuation[] = {1.0f};
GLfloat light_position[] =       { 2.0f, 5.0f, 5.0f, 0.0f };

const GLfloat mat_ambient[]    = { 0.7f, 0.7f, 0.7f, 1.0f };
const GLfloat mat_diffuse[]    = { 0.7f, 0.7f, 0.7f, 1.0f };
const GLfloat mat_specular[]   = { 1.0f, 1.0f, 1.0f, 1.0f };
const GLfloat high_shininess[] = { 100.0f };

const GLfloat maxCamY = 300.0f, minCamY = 60.0f;
GLfloat posObjeto = -5.0f;
GLfloat anguloCamaraY = 0.0f;
GLfloat anguloCamaraX = 0.0f;
GLfloat camX,camY,camZ;
GLfloat deltay = 4;

unsigned int textureID;
unsigned int textureID2;

static char label[100];
int xx[20],yy[20];
int fin=0;
float initX, initZ; //(initX,initZ) esquina superior izquierda de todo el mapa
int posX, posZ; //(posX,posZ) posición en la matriz actual del jugador
float xActual,zActual;
float rotx=0,roty=0;
int tamCubo=20,espacios=tamCubo/2;
//----------mapas------
const int altoMapa=25,largoMapa=30;
const int altoMapa2=20,largoMapa2=20;
//
int maxi = (sqrt(largoMapa*largoMapa + altoMapa*altoMapa)+3) * tamCubo;


//--mapas_matrices-----------------------------------------------------------------------------

void dibujarCadena (char *s)
{
	 unsigned int i;
	 for (i = 0; i < strlen (s); i++)
	 glutBitmapCharacter (GLUT_BITMAP_9_BY_15, s[i]);
}	
		//mapa
int mapa[altoMapa][largoMapa]= {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
                                1,0,0,5,1,17,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1,10,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1,0,1,
                                1,0,1,1,1,0,0,0,0,2,0,0,0,0,0,0,0,0,0,1,0,1,1,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,9,1,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,0,0,0,0,0,0,1,
                                1,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,1,0,1,1,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,1,8,1,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,6,1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,7,1,0,0,0,0,0,1,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,1,11,0,0,1,
                                1,16,0,0,0,0,0,0,0,1,18,0,0,0,0,0,0,0,14,1,0,0,0,0,0,1,1,1,0,1,
                                1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,1,
                                1,15,0,0,0,0,0,0,0,0,1,0,0,0,0,12,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,13,1,
                                1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};

		//mapa 2
int mapa2[altoMapa][largoMapa]= {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
                                1,0,0,5,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1,0,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1,0,1,
                                1,0,1,1,1,0,0,0,0,2,0,0,0,0,0,0,0,0,0,1,0,1,1,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,0,0,0,0,0,0,1,
                                1,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,1,0,1,1,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,6,1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,7,1,0,0,0,0,0,1,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,1,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,1,1,0,1,
                                1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};
                                
		//mapa 3
int mapa3[altoMapa][largoMapa]= {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
                                1,0,0,5,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1,0,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1,0,1,
                                1,0,1,1,1,0,0,0,0,2,0,0,0,0,0,0,0,0,0,1,0,1,1,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,9,1,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,0,0,0,0,0,0,1,
                                1,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,1,0,1,1,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,1,8,1,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,1,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,1,1,0,1,
                                1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};
                                
                                
    //mapa 4
int mapa4[altoMapa][largoMapa]= {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
                                1,0,0,5,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1,0,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1,0,1,
                                1,0,1,1,1,0,0,0,0,2,0,0,0,0,0,0,0,0,0,1,0,1,1,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,9,1,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,0,0,0,0,0,0,1,
                                1,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,1,0,1,1,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,6,1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,1,11,0,0,1,
                                1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,1,1,0,1,
                                1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,12,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};

	//mapa 5
int mapa5[altoMapa][largoMapa]= {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1,0,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1,0,1,
                                1,0,1,1,1,0,0,0,0,2,0,0,0,0,0,0,0,0,0,1,0,1,1,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,0,0,0,0,0,0,1,
                                1,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,1,0,1,1,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,6,1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,7,1,0,0,0,0,0,1,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,1,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,14,1,0,0,0,0,0,1,1,1,0,1,
                                1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,1,
                                1,15,0,0,0,0,0,0,0,0,1,0,0,0,0,12,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,13,1,
                                1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};

	//mapa 6
int mapa6[altoMapa][largoMapa]= {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
                                1,0,0,5,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1,10,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1,0,1,
                                1,0,1,1,1,0,0,0,0,2,0,0,0,0,0,0,0,0,0,1,0,1,1,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,9,1,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,0,0,0,0,0,0,1,
                                1,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,1,0,1,1,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,6,1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,7,1,0,0,0,0,0,1,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,1,11,0,0,1,
                                1,16,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,14,1,0,0,0,0,0,1,1,1,0,1,
                                1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,1,
                                1,15,0,0,0,0,0,0,0,0,1,0,0,0,0,12,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};
	
	//mapa 7
int mapa7[altoMapa][largoMapa]= {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1,0,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1,0,1,
                                1,0,1,1,1,0,0,0,0,2,0,0,0,0,0,0,0,0,0,1,0,1,1,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,0,0,0,0,0,0,1,
                                1,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,1,0,1,1,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,6,1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,7,1,0,0,0,0,0,1,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,1,11,0,0,1,
                                1,0,0,0,0,0,0,0,0,1,18,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,1,1,0,1,
                                1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};

	//mapa 8
int mapa8[altoMapa][largoMapa]= {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
                                1,0,0,5,1,17,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1,10,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1,0,1,
                                1,0,1,1,1,0,0,0,0,2,0,0,0,0,0,0,0,0,0,1,0,1,1,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,0,0,0,0,0,0,1,
                                1,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,1,0,1,1,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,6,1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,7,1,0,0,0,0,0,1,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,1,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,1,1,0,1,
                                1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,13,1,
                                1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};

	//mapa 9
int mapa9[altoMapa][largoMapa]= {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
                                1,0,0,0,1,17,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1,0,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1,0,1,
                                1,0,1,1,1,0,0,0,0,2,0,0,0,0,0,0,0,0,0,1,0,1,1,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,0,0,0,0,0,0,1,
                                1,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,1,0,1,1,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,6,1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,
                                1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,7,1,0,0,0,0,0,1,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,1,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,14,1,0,0,0,0,0,1,1,1,0,1,
                                1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,12,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
                                1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,13,1,
                                1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};


void textoScore(int E)
{
	
    char texto[32];
    sprintf(texto, "Puntos = %.0f", puntos);
    glColor3f(1, 1, 1);
    glRasterPos3f(8,11,-10);
    for(int i = 0; texto[i] != '\0'; i++)
    glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, texto[i]);
}


void textoTiempo(int E)
{
	
    char texto[32];
    sprintf(texto, "Tiempo: %.0f", tiempo);
    glColor3f(1, 1, 1);
    glRasterPos3f(7,10,-10);
    for(int i = 0; texto[i] != '\0'; i++)
    glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, texto[i]);
}


void textoFinPuntos(int E)
{
	
    char texto[32];
    sprintf(texto, " Puntuacion: %.0f", puntos);
    glColor3f(0, 0, 0);
    glRasterPos3f(-2,6,-11);
    for(int i = 0; texto[i] != '\0'; i++)
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, texto[i]);
}
void textoFinFelicidades(int E)
{
	
    char texto[40];	  
    sprintf(texto, "¡PAQUILIZCAYOLLI!", " ");
    glColor3f(0, 0, 0);
    glRasterPos3f(-2,3,-11);
    for(int i = 0; texto[i] != '\0'; i++)
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, texto[i]);
}
//texto Preaione 3

void textoPresione3(int E)
{
	
    char texto[32];
    sprintf(texto, " Presione 3 para continuar", puntos);
    glColor3f(1, 1, 1);
    glRasterPos3f(50,100 ,-2);
    for(int i = 0; texto[i] != '\0'; i++)
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, texto[i]);
}
void textoLose(int E)
{
	
    char texto[32];
    sprintf(texto, "Perdiste  %d", posX);
    glColor3f(1, 1, 1);
    glRasterPos3f(0,8,-11);
    for(int i = 0; texto[i] != '\0'; i++)
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, texto[i]);
}

//palabras---------------------------------------------------

//AGUA
void textoATL(int E)
{
	
    char texto[32];
    sprintf(texto, "Palabra: ATL", posX);
    glColor3f(1, 1, 1);
    glRasterPos3f(-2,8,-11);
    for(int i = 0; texto[i] != '\0'; i++)
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, texto[i]);
}
//RÍO
void textoAPAN(int E)
{
	
    char texto[32];
    sprintf(texto, "Palabra: APAN", posX);
    glColor3f(1, 1, 1);
    glRasterPos3f(-2,8,-11);
    for(int i = 0; texto[i] != '\0'; i++)
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, texto[i]);
}
//SOL
void textoTONATI(int E)
{
	
    char texto[32];
    sprintf(texto, "Palabra: TONATI", posX);
    glColor3f(1, 1, 1);
    glRasterPos3f(-2,8,-11);
    for(int i = 0; texto[i] != '\0'; i++)
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, texto[i]);
}
//NUBE
void textoNUBE(int E)
{
	
    char texto[32];
    sprintf(texto, "Palabra: MISHTLI", posX);
    glColor3f(1, 1, 1);
    glRasterPos3f(-2,8,-11);
    for(int i = 0; texto[i] != '\0'; i++)
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, texto[i]);
}
//HONGO
void textoHONGO(int E)
{
	
    char texto[32];
    sprintf(texto, "Palabra: SHOCHINANAKATL", posX);
    glColor3f(1, 1, 1);
    glRasterPos3f(-2,8,-11);
    for(int i = 0; texto[i] != '\0'; i++)
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, texto[i]);
}

//CORAZON
void textoYOLOTL(int E)
{
	
    char texto[32];
    sprintf(texto, "Palabra: YOLOTL", posX);
    glColor3f(1, 1, 1);
    glRasterPos3f(-2,8,-11);
    for(int i = 0; texto[i] != '\0'; i++)
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, texto[i]);
}

//CUERDA
void textoMEKATL(int E)
{
	
    char texto[32];
    sprintf(texto, "Palabra: MEKATL", posX);
    glColor3f(1, 1, 1);
    glRasterPos3f(-2,8,-11);
    for(int i = 0; texto[i] != '\0'; i++)
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, texto[i]);
}

//LUNA
void textoMESTLI(int E)
{
	
    char texto[32];
    sprintf(texto, "Palabra: MESTLI", posX);
    glColor3f(1, 1, 1);
    glRasterPos3f(-2,8,-11);
    for(int i = 0; texto[i] != '\0'; i++)
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, texto[i]);
}

//ESTRELLA
void textoSITLALLI(int E)
{
	
    char texto[32];
    sprintf(texto, "Palabra: SITLALLI", posX);
    glColor3f(1, 1, 1);
    glRasterPos3f(-2,8,-11);
    for(int i = 0; texto[i] != '\0'; i++)
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, texto[i]);
}

//Colores - Letras----------------
void textoA(int E)
{
	
    char texto[32];
    sprintf(texto, " A = Verde ", posX);
    glColor3f(1, 1, 1);
    glRasterPos3f(-13,12,-11);
    for(int i = 0; texto[i] != '\0'; i++)
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, texto[i]);
}
void textoT(int E)
{
	
    char texto[32];
    sprintf(texto, " T = Morado ", posX);
    glColor3f(1, 1, 1);
    glRasterPos3f(-13,11,-11);
    for(int i = 0; texto[i] != '\0'; i++)
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, texto[i]);
}
void textoL(int E)
{
	
    char texto[32];
    sprintf(texto, " L = Amarillo", posX);
    glColor3f(1, 1, 1);
    glRasterPos3f(-13,10,-11);
    for(int i = 0; texto[i] != '\0'; i++)
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, texto[i]);
}
void textoP(int E)
{
	
    char texto[32];
    sprintf(texto, " P = Naranja ", posX);
    glColor3f(1, 1, 1);
    glRasterPos3f(-13,9,-11);
    for(int i = 0; texto[i] != '\0'; i++)
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, texto[i]);
}
void textoN(int E)
{
	
    char texto[32];
    sprintf(texto, " N = Azul", posX);
    glColor3f(1, 1, 1);
    glRasterPos3f(-13,8,-11);
    for(int i = 0; texto[i] != '\0'; i++)
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, texto[i]);
}
void textoK(int E)
{
	
    char texto[32];
    sprintf(texto, " K = Verde oscuro", posX);
    glColor3f(1, 1, 1);
    glRasterPos3f(-13,7,-11);
    for(int i = 0; texto[i] != '\0'; i++)
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, texto[i]);
}
void textoO(int E)
{
	
    char texto[32];
    sprintf(texto, " O = Celeste", posX);
    glColor3f(1, 1, 1);
    glRasterPos3f(-13,6,-11);
    for(int i = 0; texto[i] != '\0'; i++)
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, texto[i]);
}
void textoI(int E)
{
	
    char texto[32];
    sprintf(texto, " I = Rojo", posX);
    glColor3f(1, 1, 1);
    glRasterPos3f(-13,5,-11);
    for(int i = 0; texto[i] != '\0'; i++)
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, texto[i]);
}
void textoM(int E)
{
	
    char texto[32];
    sprintf(texto, " M = Violeta", posX);
    glColor3f(1, 1, 1);
    glRasterPos3f(-13,4,-11);
    for(int i = 0; texto[i] != '\0'; i++)
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, texto[i]);
}
void textoS(int E)
{
	
    char texto[32];
    sprintf(texto, " S = Piel", posX);
    glColor3f(1, 1, 1);
    glRasterPos3f(-13,3,-11);
    for(int i = 0; texto[i] != '\0'; i++)
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, texto[i]);
}
void textoH(int E)
{
	
    char texto[32];
    sprintf(texto, " H = Gris", posX);
    glColor3f(1, 1, 1);
    glRasterPos3f(-13,2,-11);
    for(int i = 0; texto[i] != '\0'; i++)
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, texto[i]);
}
void textoC(int E)
{
	
    char texto[32];
    sprintf(texto, " C = Marron", posX);
    glColor3f(1, 1, 1);
    glRasterPos3f(-13,1,-11);
    for(int i = 0; texto[i] != '\0'; i++)
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, texto[i]);
}
void textoE(int E)
{
	
    char texto[32];
    sprintf(texto, " E = Negro", posX);
    glColor3f(1, 1, 1);
    glRasterPos3f(-13,0,-11);
    for(int i = 0; texto[i] != '\0'; i++)
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, texto[i]);
}
void textoY(int E)
{
	
    char texto[32];
    sprintf(texto, " Y = Verde claro");
    glColor3f(1, 1, 1);
    glRasterPos3f(-13,-1,-11);
    for(int i = 0; texto[i] != '\0'; i++)
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, texto[i]);
}


void textoLetras(int E)
{
	
    char texto[32];
    sprintf(texto, "Letra: %s", palabra);
   
    glColor3f(1, 1, 1);
    glRasterPos3f(0-2,7,-11);
    for(int i = 0; texto[i] != '\0'; i++)
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, texto[i]);
}

// TEXTURAS-------------------------------------------------------------------
void imagenSOL()
{
	
	texture[0] = SOIL_load_OGL_texture // load an image file directly as a new OpenGL texture
    (
        "imagenes/SOL.png",
        SOIL_LOAD_AUTO,
        SOIL_CREATE_NEW_ID,
        SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
    );

	// allocate a texture name
	 glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texture[0]);
	
    glBegin(GL_POLYGON);
    glNormal3f( 0.0f, 0.0f, 1.0f);
    glTexCoord2f(0.0f, 0.0f); glVertex3f( -60.0,   0.0, 0.0);
    glTexCoord2f(1.0f, 0.0f); glVertex3f(  60.0,   0.0, 0.0);
    glTexCoord2f(1.0f, 1.0f); glVertex3f(  60.0,  120.0, -40.0);
    glTexCoord2f(0.0f, 1.0f); glVertex3f( -60.0,  120.0, -40.0);
    
    glEnd();

}
void imagenAGUA()
{
	
	texture[0] = SOIL_load_OGL_texture // load an image file directly as a new OpenGL texture
    (
        "imagenes/AGUA.png",
        SOIL_LOAD_AUTO,
        SOIL_CREATE_NEW_ID,
        SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
    );

	// allocate a texture name
	 glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texture[0]);
	
    glBegin(GL_POLYGON);
    glNormal3f( 0.0f, 0.0f, 1.0f);
    glTexCoord2f(0.0f, 0.0f); glVertex3f( -60.0,   0.0, 0.0);
    glTexCoord2f(1.0f, 0.0f); glVertex3f(  60.0,   0.0, 0.0);
    glTexCoord2f(1.0f, 1.0f); glVertex3f(  60.0,  120.0, -40.0);
    glTexCoord2f(0.0f, 1.0f); glVertex3f( -60.0,  120.0, -40.0);
    
    glEnd();

}
void imagenRIO()
{
	
	texture[0] = SOIL_load_OGL_texture // load an image file directly as a new OpenGL texture
    (
        "imagenes/RIO.png",
        SOIL_LOAD_AUTO,
        SOIL_CREATE_NEW_ID,
        SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
    );

	// allocate a texture name
	 glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texture[0]);
	
    glBegin(GL_POLYGON);
    glNormal3f( 0.0f, 0.0f, 1.0f);
    glTexCoord2f(0.0f, 0.0f); glVertex3f( -60.0,   0.0, 0.0);
    glTexCoord2f(1.0f, 0.0f); glVertex3f(  60.0,   0.0, 0.0);
    glTexCoord2f(1.0f, 1.0f); glVertex3f(  60.0,  120.0, -40.0);
    glTexCoord2f(0.0f, 1.0f); glVertex3f( -60.0,  120.0, -40.0);
    
    glEnd();

}
void imagenNUBE()
{
	
	texture[0] = SOIL_load_OGL_texture // load an image file directly as a new OpenGL texture
    (
        "imagenes/NUBE.png",
        SOIL_LOAD_AUTO,
        SOIL_CREATE_NEW_ID,
        SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
    );

	// allocate a texture name
	 glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texture[0]);
	
    glBegin(GL_POLYGON);
    glNormal3f( 0.0f, 0.0f, 1.0f);
    glTexCoord2f(0.0f, 0.0f); glVertex3f( -60.0,   0.0, 0.0);
    glTexCoord2f(1.0f, 0.0f); glVertex3f(  60.0,   0.0, 0.0);
    glTexCoord2f(1.0f, 1.0f); glVertex3f(  60.0,  120.0, -40.0);
    glTexCoord2f(0.0f, 1.0f); glVertex3f( -60.0,  120.0, -40.0);
    
    glEnd();

}
void imagenHONGO()
{
	
	texture[0] = SOIL_load_OGL_texture // load an image file directly as a new OpenGL texture
    (
        "imagenes/HONGO.png",
        SOIL_LOAD_AUTO,
        SOIL_CREATE_NEW_ID,
        SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
    );

	// allocate a texture name
	 glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texture[0]);
	
    glBegin(GL_POLYGON);
    glNormal3f( 0.0f, 0.0f, 1.0f);
    glTexCoord2f(0.0f, 0.0f); glVertex3f( -60.0,   0.0, 0.0);
    glTexCoord2f(1.0f, 0.0f); glVertex3f(  60.0,   0.0, 0.0);
    glTexCoord2f(1.0f, 1.0f); glVertex3f(  60.0,  120.0, -40.0);
    glTexCoord2f(0.0f, 1.0f); glVertex3f( -60.0,  120.0, -40.0);
    
    glEnd();

}

void imagenCORAZON()
{
	
	texture[0] = SOIL_load_OGL_texture // load an image file directly as a new OpenGL texture
    (
        "imagenes/CORAZON.png",
        SOIL_LOAD_AUTO,
        SOIL_CREATE_NEW_ID,
        SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
    );

	// allocate a texture name
	 glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texture[0]);
	
    glBegin(GL_POLYGON);
    glNormal3f( 0.0f, 0.0f, 1.0f);
    glTexCoord2f(0.0f, 0.0f); glVertex3f( -60.0,   0.0, 0.0);
    glTexCoord2f(1.0f, 0.0f); glVertex3f(  60.0,   0.0, 0.0);
    glTexCoord2f(1.0f, 1.0f); glVertex3f(  60.0,  120.0, -40.0);
    glTexCoord2f(0.0f, 1.0f); glVertex3f( -60.0,  120.0, -40.0);
    
    glEnd();

}

void imagenCUERDA()
{
	
	texture[0] = SOIL_load_OGL_texture // load an image file directly as a new OpenGL texture
    (
        "imagenes/CUERDA.png",
        SOIL_LOAD_AUTO,
        SOIL_CREATE_NEW_ID,
        SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
    );

	// allocate a texture name
	 glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texture[0]);
	
    glBegin(GL_POLYGON);
    glNormal3f( 0.0f, 0.0f, 1.0f);
    glTexCoord2f(0.0f, 0.0f); glVertex3f( -60.0,   0.0, 0.0);
    glTexCoord2f(1.0f, 0.0f); glVertex3f(  60.0,   0.0, 0.0);
    glTexCoord2f(1.0f, 1.0f); glVertex3f(  60.0,  120.0, -40.0);
    glTexCoord2f(0.0f, 1.0f); glVertex3f( -60.0,  120.0, -40.0);
    
    glEnd();

}
void imagenESTRELLA()
{
	
	texture[0] = SOIL_load_OGL_texture // load an image file directly as a new OpenGL texture
    (
        "imagenes/ESTRELLA.png",
        SOIL_LOAD_AUTO,
        SOIL_CREATE_NEW_ID,
        SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
    );

	// allocate a texture name
	 glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texture[0]);
	
    glBegin(GL_POLYGON);
    glNormal3f( 0.0f, 0.0f, 1.0f);
    glTexCoord2f(0.0f, 0.0f); glVertex3f( -60.0,   0.0, 0.0);
    glTexCoord2f(1.0f, 0.0f); glVertex3f(  60.0,   0.0, 0.0);
    glTexCoord2f(1.0f, 1.0f); glVertex3f(  60.0,  120.0, -40.0);
    glTexCoord2f(0.0f, 1.0f); glVertex3f( -60.0,  120.0, -40.0);
    
    glEnd();

}
void imagenLUNA()
{
	
	texture[0] = SOIL_load_OGL_texture // load an image file directly as a new OpenGL texture
    (
        "imagenes/LUNA.png",
        SOIL_LOAD_AUTO,
        SOIL_CREATE_NEW_ID,
        SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
    );

	// allocate a texture name
	 glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texture[0]);
	
    glBegin(GL_POLYGON);
    glNormal3f( 0.0f, 0.0f, 1.0f);
    glTexCoord2f(0.0f, 0.0f); glVertex3f( -60.0,   0.0, 0.0);
    glTexCoord2f(1.0f, 0.0f); glVertex3f(  60.0,   0.0, 0.0);
    glTexCoord2f(1.0f, 1.0f); glVertex3f(  60.0,  120.0, -40.0);
    glTexCoord2f(0.0f, 1.0f); glVertex3f( -60.0,  120.0, -40.0);
    
    glEnd();

}

struct ttextura_gimp {
  unsigned int     width;
  unsigned int     height;
  unsigned int     bytes_per_pixel; /* 3:RGB, 4:RGBA */
  unsigned char    pixel_data[300 * 300 * 3 + 1];
};

struct ttextura_gimp textura_verde = {
 300, 300, 3,
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061"
  "\013P\061\013P\061\013P\061\013P\061\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\012"
  "O\060\012O\060\012O\060\012O\060\011N/\011N/\011N/\011N/\011N/\011N/\011N\061\011N\061\011"
  "N\061\011N\061\011N\061\011N\061\011N\061\010M\060\011N\061\011N\061\011N\061\011N\061\011N\061"
  "\011N\061\011N\061\011N\061\010M.\010M.\010M.\010M.\010M.\010M.\010M.\010M.\007L-\007L-\007L"
  "-\007L-\007L-\007L-\007L-\007L-\007L-\007L-\006K,\006K,\005L,\005L,\005L,\005L,\005L,\005L,\005L,\005L,\002L"
  "+\002L+\002L+\002L+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\003J*\003J*\003J*\003J"
  "*\003J*\003J*\003J*\003J*\003J*\003J*\003J*\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\012"
  "O\060\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\011N/"
  "\011N/\011N/\011N/\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011"
  "N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N/\010M.\010M.\010M"
  ".\010M.\010M.\010M.\010M.\007L-\007L-\007L-\007L-\007L-\007L-\007L-\007L-\007L-\007L-\007L-\006K,\006K"
  ",\006K,\005L,\005L,\005L,\005L,\005L,\005L,\004K+\004K+\002L+\002L+\004K+\004K+\004K+\004K+\004K+\004K+\004K"
  "+\004K+\004K+\004K+\004K+\004K+\003J*\003J*\003J*\003J*\003J*\003J*\003J*\003J*\003J*\003J*\016S\064\016S"
  "\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013"
  "P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\012O\060\012O\060\012O\060\012O\060"
  "\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\011N/\011N/\011N\061\011N\061\011N\061"
  "\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011"
  "N\061\011N\061\011N\061\011N/\011N/\011N/\010M.\010M.\010M.\010M.\010M.\010M.\007L-\007L-\007"
  "L-\007L-\007L-\007L-\007L-\007L-\007L-\007L-\007L-\006K,\006K,\005L,\005L,\005L,\005L,\005L,\005L,\005L,\004"
  "K+\002L+\002L+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\003J*\003J*\003J*\003"
  "J*\003J*\003J*\003J*\003J*\003J*\003J*\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\016S"
  "\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013"
  "P\061\013P\061\013P\061\013P\061\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060"
  "\012O\060\012O\060\012O\060\012O\062\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011"
  "N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N/\011N/\011"
  "N/\011N/\010M.\010M.\010M.\010M.\010M.\010M.\010M.\007L-\007L-\007L-\007L-\007L-\007L-\007L-\007"
  "L-\007L-\006K,\006K,\005L,\005L,\005L,\005L,\005L,\005L,\005L,\005L,\005L,\004K+\004K+\004K+\004K+\004K+\004"
  "K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\003J*\003J*\003J*\003J*\003J*\003J*\003J*\003J*\003J*\017"
  "T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065"
  "\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017"
  "T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\015R\063\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061"
  "\013P\061\013P\061\013P\061\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\012O\062\012"
  "O\062\012O\062\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061"
  "\011N\061\011N\061\011N\061\011N\061\011N/\011N/\011N/\011N/\010M.\010M.\010M.\010M.\010M"
  ".\010M.\010M.\010M.\007L-\007L-\007L-\007L-\007L-\007L-\007L-\007L-\007L-\006K,\005L,\005L,\005L,\005L,"
  "\005L,\005L,\005L,\005L,\005L,\005L,\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+"
  "\004K+\004K+\004K+\003J*\003J*\003J*\003J*\003J*\003J*\003J*\021T\065\021T\065\021T\065\021T\065\021T"
  "\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\017T\065\017T\065\017T\065\017"
  "T\065\017T\065\017T\065\017T\065\017T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061"
  "\013P\061\012O\060\012O\060\012O\060\012O\060\012O\062\012O\062\012O\062\011N\061\011N\061\011"
  "N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061"
  "\011N/\011N/\011N/\011N/\011N/\010M.\010M.\010M.\010M.\010M.\010M.\010M.\007L-\007L-\007L-"
  "\007L-\007L-\007L-\007L-\007L-\007L-\007L-\006K,\006K,\005L,\005L,\005L,\005L,\005L,\005L,\005L,\005L,\004K+"
  "\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\003J*\003J*\003J*"
  "\003J*\003J*\003J*\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T"
  "\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017"
  "T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\015R\063\015R\063"
  "\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013"
  "P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\012O\060\012O\060\012O\060"
  "\012O\060\012O\062\012O\062\012O\062\012O\062\011N\061\011N\061\011N\061\011N\061\011N\061\011"
  "N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N/\011N/\011N/\011N/\011N/\011"
  "N/\010M.\010M.\010M.\010M.\010M.\010M.\010M.\007L-\007L-\007L-\007L-\007L-\007L-\007L-\007L-\007L"
  "-\007L-\006K,\005L,\005L,\005L,\005L,\005L,\005L,\005L,\005L,\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K"
  "+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\003J*\003J*\003J*\003J*\003J*\003J*\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020"
  "S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064"
  "\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020"
  "S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064"
  "\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020"
  "S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064"
  "\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020"
  "S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064"
  "\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020"
  "S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064"
  "\020S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013"
  "P\061\013P\061\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061"
  "\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\012O\062\012O\062\012O\062\012"
  "O\062\012O\062\012O\062\012O\062\012O\062\012O\062\011N\061\011N\061\011N\061\011N\061\011N\061"
  "\011N\061\011N\061\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\010M.\010M.\010M.\010"
  "M.\010M.\010M.\010M.\010M.\012M.\012M.\007L-\007L-\007L-\007L-\007L-\007L-\007L-\006K,\005L,\005L,"
  "\005L,\005L,\005L,\005L,\005L,\005L,\005L,\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+"
  "\004K+\004K+\004K+\004K+\003J*\003J*\003J*\003J*\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064"
  "\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013P\061\013"
  "P\061\013P\061\013P\061\013P\061\012O\062\012O\062\012O\062\012O\062\012O\062\012O\062\012O\062"
  "\012O\062\012O\062\012O\062\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N/\011N"
  "/\011N/\011N/\011N/\011N/\011N/\011N/\010M.\010M.\010M.\010M.\010M.\010M.\010M.\010M.\012"
  "M.\012M.\010M.\007L-\007L-\007L-\007L-\007L-\007L-\007L-\005L,\005L,\005L,\005L,\005L,\005L,\005L,\005L,"
  "\005L,\005L,\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\003J*"
  "\003J*\003J*\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020S\064\020S\064\020S\064\020"
  "S\064\020S\064\020S\064\020S\064\020S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061"
  "\012O\062\012O\062\012O\062\012O\062\012O\062\012O\062\012O\062\012O\062\012O\062\012O\062\012"
  "O\062\011N\061\011N\061\011N\061\011N\061\011N\061\011N/\011N/\011N/\011N/\011N/\011N/\011"
  "N/\011N/\011N/\010M.\010M.\010M.\010M.\010M.\010M.\010M.\012M.\012M.\012M.\012M.\011L-"
  "\011L-\007L-\007L-\007L-\007L-\007L-\006K,\006K,\006K,\005L,\005L,\005L,\005L,\005L,\005L,\004K+\004K+\004K"
  "+\004K+\005L,\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\003J*\003J*\022U\066\022U"
  "\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013P\061\013P\061\013P\063\012O\062\012"
  "O\062\012O\062\012O\062\012O\062\012O\062\012O\062\012O\062\012O\062\012O\062\012O\062\011N\061"
  "\011N\061\011N\061\011N\061\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011"
  "N/\010M.\010M.\010M.\010M.\010M.\012M.\012M.\012M.\012M.\011L-\011L-\007L-\007L-\007L-\007L"
  "-\007L-\007L-\006K,\006K,\005L,\005L,\005L,\005L,\005L,\005L,\005L,\004K+\004K+\004K+\005L,\005L,\005L,\004K"
  "+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\003J*\003J*\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\013P\061\013P\061\013P\061\013P\061\013P\063\013P\063\013P\063\012O\062\012O\062\012"
  "O\062\012O\062\012O\062\012O\062\012O\062\012O\062\012O\062\011N\061\011N\061\011N\061\011N\061"
  "\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\010M.\010M.\010"
  "M.\010M.\012M.\012M.\012M.\012M.\012M.\011L-\007L-\007L-\007L-\007L-\007L-\007L-\006K,\006K,\006K"
  ",\006K,\005L,\005L,\005L,\005L,\005L,\005L,\005L,\004K+\005L,\005L,\005L,\005L,\004K+\004K+\004K+\004K+\004K"
  "+\004K+\004K+\004K+\004K+\003J*\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061"
  "\013P\061\013P\061\013P\063\013P\063\013P\063\013P\063\012O\062\012O\062\012O\062\012O\062\012"
  "O\062\012O\062\012O\062\012O\062\012O\062\011N\061\011N\061\011N\061\011N/\011N/\011N/\011N"
  "/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\010M.\010M.\010M.\010M.\012M.\012M.\012"
  "M.\012M.\012M.\012M.\010M.\007L-\007L-\007L-\007L-\007L-\007L-\006K,\006K,\006K,\005L,\005L,\005L,\005"
  "L,\005L,\005L,\005L,\005L,\005L,\005L,\005L,\005L,\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004"
  "K+\024U\067\024U\067\024U\067\024U\067\024U\067\024U\067\024U\067\024U\067\024U\067\024U\067"
  "\024U\067\024U\067\024U\067\024U\067\024U\067\024U\067\024U\067\024U\067\024U\067\024U\067\024"
  "U\067\024U\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017"
  "T\065\017T\065\017T\065\017T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013"
  "P\063\013P\063\013P\063\013P\063\012O\062\012O\062\012O\062\012O\062\012O\062\012O\062\012O\062"
  "\012O\062\012O\062\012O\062\011N\061\011N\061\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011"
  "N/\011N/\011N/\011N/\011N/\011N/\010M.\010M.\010M.\012M.\012M.\012M.\012M.\012M.\012M."
  "\012M.\012M.\007L-\007L-\007L-\007L-\007L-\007L-\006K,\006K,\005L,\005L,\005L,\005L,\005L,\005L,\005L,\005"
  "L,\005L,\005L,\005L,\005L,\005L,\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\024U\067\024U\067"
  "\024U\067\024U\067\024U\067\024U\067\024U\067\024U\067\024U\067\024U\067\024U\067\024U\067\024"
  "U\067\024U\067\024U\067\024U\067\024U\067\024U\067\024U\067\024U\067\024U\067\024U\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065"
  "\017T\065\017T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\063\013P\063\013P\063"
  "\013P\063\013P\063\012O\062\012O\062\012O\062\012O\062\012O\062\012O\062\012O\062\012O\062\012"
  "O\062\012O\062\011N\061\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N"
  "/\011N/\011N/\011N/\010M.\010M.\012M.\012M.\012M.\012M.\012M.\012M.\012M.\012M.\007L-\007"
  "L-\007L-\007L-\007L-\007L-\007L-\006K,\005L,\005L,\005L,\005L,\005L,\005L,\005L,\005L,\005L,\005L,\005L,\005"
  "L,\005L,\005L,\004K+\004K+\004K+\004K+\004K+\004K+\004K+\004K+\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\020S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013"
  "P\061\013P\061\013P\061\013P\061\013P\061\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060"
  "\012O\060\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/"
  "\011N/\011N/\011N/\011N/\011N/\010M.\010M.\010M.\010M.\010M.\010M.\010M.\007L-\007L-\007L-"
  "\007L-\007L-\007L-\007L-\007L-\007L-\007L-\006K,\006K,\006K,\006K,\006K,\006K,\006K,\006K,\006K,\006K,\006K,"
  "\006K,\004K+\004K+\004K+\004K+\004K+\004K+\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\017T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013"
  "P\061\013P\061\013P\061\013P\061\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060"
  "\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011"
  "N/\011N/\011N/\011N/\010M.\010M.\010M.\010M.\010M.\010M.\010M.\007L-\007L-\007L-\007L-\007L-"
  "\007L-\007L-\007L-\007L-\007L-\006K,\006K,\006K,\006K,\006K,\006K,\006K,\006K,\006K,\006K,\006K,\004K+\004K+"
  "\004K+\004K+\004K+\004K+\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\017T\065\017T\065\017T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013P\061\013P\061"
  "\013P\061\013P\061\013P\061\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\011"
  "N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/"
  "\011N/\011N/\010M.\010M.\010M.\010M.\010M.\010M.\010M.\010M.\007L-\007L-\007L-\007L-\007L-\007"
  "L-\007L-\007L-\007L-\006K,\006K,\006K,\006K,\006K,\006K,\006K,\006K,\006K,\006K,\006K,\005L,\004K+\004K+\004"
  "K+\004K+\004K+\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\021T\065\021T\065\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\017T\065\017T\065\017T\065\017T\065\017T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013P\061\013P\061"
  "\013P\061\013P\061\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\011"
  "N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/"
  "\011N/\011N/\010M.\010M.\010M.\010M.\010M.\010M.\010M.\007L-\007L-\007L-\007L-\007L-\007L-\007L"
  "-\007L-\007L-\007L-\007L-\006K,\006K,\006K,\006K,\006K,\006K,\006K,\006K,\006K,\005L,\005L,\005L,\004K+\004K"
  "+\004K+\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W"
  "\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\017"
  "T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013"
  "P\061\013P\061\013P\061\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\011N/"
  "\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011"
  "N/\011N/\011N/\011N/\010M.\010M.\010M.\010M.\010M.\010M.\007L-\007L-\007L-\007L-\007L-\007L-\007"
  "L-\007L-\007L-\007L-\007L-\006K,\006K,\006K,\006K,\006K,\006K,\006K,\006K,\005L,\005L,\005L,\005L,\004K+\004"
  "K+\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\020U\066"
  "\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061"
  "\013P\061\013P\061\013P\061\013P\061\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\011"
  "N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/"
  "\011N/\011N/\011N/\011N/\010M.\010M.\010M.\010M.\010M.\010M.\010M.\007L-\007L-\007L-\007L-\007"
  "L-\007L-\007L-\007L-\007L-\006K,\006K,\006K,\006K,\006K,\006K,\006K,\006K,\005L,\005L,\005L,\005L,\004K+\004"
  "K+\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W"
  "\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020S\064\020S\064\020S\064\020S\064"
  "\020S\064\020S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013P\061\013P\061\013"
  "P\061\013P\061\013P\061\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\011N/\011N/\011"
  "N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/"
  "\011N/\010M.\010M.\010M.\010M.\010M.\010M.\010M.\010M.\010M.\007L-\007L-\007L-\007L-\007L-\007"
  "L-\007L-\006K,\006K,\006K,\006K,\006K,\006K,\006K,\006K,\005L,\005L,\005L,\005L,\005L,\004K+\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V"
  ":\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W"
  "\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\023V\067\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020S\064\020S\064\020S\064\020S\064\020S\064"
  "\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013"
  "P\061\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\011N/\011N/\011N/\011N"
  "/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\010M.\010"
  "M.\010M.\010M.\010M.\010M.\010M.\010M.\010M.\010M.\007L-\007L-\007L-\007L-\007L-\007L-\006K,\006"
  "K,\006K,\006K,\006K,\006K,\006K,\006K,\005L,\005L,\005L,\005L,\005L,\005L,\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\020S\064\020S\064\020S\064\020S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061"
  "\013P\061\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013"
  "P\061\013P\061\013P\061\013P\061\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060"
  "\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011"
  "N/\010M.\010M.\010M.\010M.\010M.\010M.\010M.\010M.\010M.\010M.\007L-\007L-\007L-\007L-\007L-"
  "\007L-\007L-\007L-\007L-\007L-\007L-\006M-\005L,\005L,\005L,\005L,\005L,\024V:\024V:\024V:\024V:\024V"
  ":\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W"
  "\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\020S\064\020S\064\020S\064\020S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\013P\061\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013P\061\013P\061\013"
  "P\061\013P\061\013P\061\013P\061\013P\061\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060"
  "\012O\060\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/"
  "\011N/\011N/\010M.\010M.\010M.\010M.\010M.\010M.\010M.\010M.\010M.\010M.\007L-\007L-\007L-"
  "\007L-\007L-\007L-\007L-\007L-\007L-\007L-\006M-\006M-\005L,\005L,\005L,\005L,\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W"
  "\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020S\064\020S\064\017T\065\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061"
  "\013P\061\013P\061\013P\061\013P\061\013P\061\012O\060\012O\060\012O\060\012O\060\012O\060\012"
  "O\060\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011"
  "N/\011N/\010M.\010M.\010M.\010M.\010M.\010M.\010M.\010M.\010M.\010M.\010M.\007L-\007L-\007"
  "L-\007L-\007L-\007L-\007L-\007L-\007L-\006M-\006M-\006M-\005L,\005L,\005L,\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\017T\065\017T\065\017T\065"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013P\061\013P\061\013"
  "P\061\013P\061\013P\061\013P\061\013P\061\013P\061\012O\060\012O\060\012O\060\012O\060\012O\060"
  "\012O\060\012O\060\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011"
  "N/\011N/\011N/\010M.\010M.\010M.\010M.\010M.\010M.\010M.\010M.\010M.\010M.\010M.\007L-\007"
  "L-\007L-\007L-\007L-\007L-\007L-\007L-\006M-\006M-\006M-\006M-\005L,\005L,\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\017T\065\017T\065\017T\065"
  "\017T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013"
  "P\061\013P\061\013P\061\013P\061\013P\061\013P\061\012O\060\012O\060\012O\060\012O\060\012O\060"
  "\012O\060\012O\060\012O\060\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011"
  "N/\011N/\011N/\011N/\011N/\010M.\010M.\010M.\010M.\010M.\010M.\010M.\010M.\010M.\007L-\007"
  "L-\007L-\007L-\007L-\007L-\007L-\007L-\006M-\006M-\006M-\006M-\005L,\005L,\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\017T\065\017T\065\017T\065"
  "\017T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013"
  "P\061\013P\061\013P\061\013P\061\013P\061\013P\061\012O\060\012O\060\012O\060\012O\060\012O\060"
  "\012O\060\012O\060\012O\060\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011"
  "N/\011N/\011N/\011N/\011N/\011N/\011N/\010M.\010M.\010M.\010M.\010M.\010M.\010M.\007L-\007"
  "L-\007L-\007L-\007L-\007L-\007L-\007L-\006M-\006M-\006M-\006M-\006M-\005L,\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067"
  "\023V\067\023V\067\024U\067\024U\067\024U\067\024U\067\024U\067\024U\067\024U\067\023T\066\023"
  "T\066\023T\066\023T\066\023T\066\023T\066\023T\066\022S\065\021T\065\017T\065\017T\065\017T\065"
  "\017T\065\017T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013"
  "P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\012O\060\012O\060\012O\060\012O\060"
  "\012O\060\012O\060\012O\060\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011"
  "N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\010M.\010M.\010M.\010M.\010M.\010M.\010M."
  "\010M.\010M.\010M.\010M.\010M.\010M.\010M.\006M-\006M-\006M-\006M-\006M-\006M-\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\023V\067\023V\067\023V\067\024U\067\024U\067\024U\067\024U\067\024U\067\024U\067\024U\067"
  "\024U\067\023T\066\023T\066\023T\066\023T\066\023T\066\023T\066\023T\066\021T\065\021T\065\017"
  "T\065\017T\065\017T\065\017T\065\017T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\012O\060\012"
  "O\060\012O\060\012O\060\012O\060\012O\060\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/"
  "\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\010M.\010M.\010M.\010"
  "M.\010M.\010M.\010M.\010M.\010M.\010M.\010M.\010M.\010M.\006M-\006M-\006M-\006M-\006M-\006M-\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:"
  "\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026"
  "Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\023U\071"
  "\023U\071\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\023V"
  "\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020"
  "S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\016S\064\016S\064\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\013P\061\013P\061\013P\061\013P\061\013P\061\012O\060\012O\060\012O\060\012O\062\011N\061\011"
  "N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061"
  "\011N\061\010M\060\010M\060\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\010M.\010M.\010"
  "M.\010M.\010M.\010M.\010M.\010M.\010M.\010M.\007L-\007L-\007L-\007L-\026X<\026X<\026X<\026X"
  "<\026X<\026X<\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026"
  "Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:"
  "\026Y:\026Y:\026Y:\026Y:\026Y:\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\023U\071\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020S\064\020S\064"
  "\020S\064\020S\064\020S\064\020S\064\020S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013"
  "P\061\013P\061\013P\061\013P\061\012O\060\012O\060\012O\062\012O\062\011N\061\011N\061\011N\061"
  "\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\010"
  "M\060\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\010M.\010M.\010M.\010M.\010M.\010"
  "M.\010M.\010M.\010M.\010M.\010M.\007L-\007L-\007L-\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:"
  "\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026"
  "Y:\026Y:\026Y:\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020S\064\020S\064\020"
  "S\064\020S\064\020S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013P\061\013P\061"
  "\013P\061\013P\061\012O\060\012O\062\012O\062\012O\062\012O\062\011N\061\011N\061\011N\061\011"
  "N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N/\011N/\011"
  "N/\011N/\011N/\011N/\011N/\011N/\011N/\010M.\010M.\010M.\010M.\010M.\010M.\010M.\010M."
  "\010M.\010M.\010M.\007L-\007L-\026X<\026X<\026X<\026X<\026X<\026X<\026Y:\026Y:\026Y:\026Y"
  ":\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026"
  "Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020S\064\020S\064\020S\064"
  "\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013"
  "P\061\012O\062\012O\062\012O\062\012O\062\012O\062\012O\062\011N\061\011N\061\011N\061\011N\061"
  "\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N/\011N/\011N/\011N/\011N/\011N/"
  "\011N/\011N/\011N/\011N/\011N/\010M.\010M.\010M.\010M.\010M.\010M.\010M.\010M.\010M.\007"
  "L-\007L-\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Y=\027Y=\027Y=\027Y=\027"
  "Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y="
  "\027Y=\027Y=\027Y=\027Y=\027Y=\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\012O\062\012O\062"
  "\012O\062\012O\062\012O\062\012O\062\012O\062\012O\062\012O\062\011N\061\011N\061\011N\061\011"
  "N\061\011N\061\011N\061\011N\061\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011"
  "N/\011N/\011N/\010M.\010M.\010M.\010M.\010M.\010M.\010M.\010M.\010M.\007L-\027Y=\027Y=\027"
  "Y=\027Y=\027Y=\027Y=\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y="
  "\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027"
  "Y=\027Y=\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\022U\066\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061"
  "\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\063\013P\063\012O\062\012O\062\012"
  "O\062\012O\062\012O\062\012O\062\012O\062\012O\062\012O\062\011N\061\011N\061\011N\061\011N\061"
  "\011N\061\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N/\010M."
  "\010M.\010M.\010M.\010M.\010M.\010M.\010M.\010M.\010M.\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\022U\066\022U\066\022U\066\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061"
  "\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\012O\060\012O\060\012"
  "O\060\012O\060\012O\060\012O\060\012O\060\011N/\011N/\011N/\011N/\011N/\011N\061\011N\061\011"
  "N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061"
  "\010M\060\010M\060\010M\060\010M.\010M.\010M.\010M.\010M.\010M.\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\022U\066\022U\066\022U\066\022U\066"
  "\021T\065\021T\065\021T\065\021T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013"
  "P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\012O\060\012O\060"
  "\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\011N/\011N/\011N/\011N/\011N\061\011"
  "N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061"
  "\011N\061\011N\061\010M\060\010M\060\010M.\010M.\010M.\010M.\010M.\010M.\027Z;\027Z;\027Z"
  ";\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\023V\067\023V\067\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\021T\065\021T\065\021T\065\021T\065\017T\065\017T\065\017T\065\017T\065\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013P\061\013P\061"
  "\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\012"
  "O\060\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061"
  "\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\010M.\010M.\010M.\010M.\010M.\010M."
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W"
  "\070\024W\070\024W\070\024W\070\023V\067\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\017T\065\017T\065\017T\065"
  "\017T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013"
  "P\061\013P\061\013P\061\013P\061\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060"
  "\012O\060\012O\060\012O\060\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011"
  "N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\010M.\010M.\010"
  "M.\010M.\010M.\010M.\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026Y:\026Y:\026Y:\026Y:\026"
  "Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026X<\026X<\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\017"
  "T\065\017T\065\017T\065\017T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\012O\060\012O\060\012"
  "O\060\012O\060\012O\060\012O\060\012O\060\012O\060\011N\061\011N\061\011N\061\011N\061\011N\061"
  "\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011"
  "N\061\011N/\011N/\011N/\011N/\011N/\011N/\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026Y:"
  "\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026"
  "Y:\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\021T\065\017T\065\017T\065\017T\065\017T\065\017T\065\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061"
  "\013P\061\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\011N\061\011N\061\011"
  "N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061"
  "\011N\061\011N\061\011N\061\011N/\011N/\011N/\011N/\011N/\011N/\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026Y:\026Y:\026Y:\026Y:\026"
  "Y:\026Y:\026Y:\026Y:\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025X\071\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\020U\066\017T\065\017T\065\017T\065\017T\065\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061"
  "\013P\061\013P\061\013P\061\013P\061\013P\061\012O\060\012O\060\012O\060\012O\060\012O\060\012"
  "O\062\012O\062\012O\062\012O\062\012O\062\012O\062\012O\062\012O\062\011N\061\011N\061\011N\061"
  "\011N\061\011N\061\011N\061\011N\061\011N\061\011N/\011N/\011N/\011N/\011N/\011N/\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026Y:\026"
  "Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025X\071\025X\071\025X\071\024W\070\024W"
  "\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\020U\066\020U\066\017T\065\017T\065"
  "\017T\065\017T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\012O\060\012O\060"
  "\012O\060\012O\060\012O\062\012O\062\012O\062\012O\062\012O\062\012O\062\012O\062\012O\062\011"
  "N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N/\011N/\011N/\011N"
  "/\011N/\011N/\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\027Y=\027Y=\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025X\071\025X\071\025"
  "X\071\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\020U\066\020U\066"
  "\017T\065\017T\065\017T\065\017T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013P\061"
  "\012O\060\012O\060\012O\060\012O\060\012O\062\012O\062\012O\062\012O\062\012O\062\012O\062\012"
  "O\062\012O\062\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011N/"
  "\011N/\011N/\011N/\011N/\011N/\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\027Y=\027"
  "Y=\027Y=\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025X\071\025X\071\025X\071\025X\071\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\020U\066\020U\066\017T\065\017T\065\017T\065\017T\065\017T\065\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013"
  "P\061\013P\061\013P\061\013P\061\012O\060\012O\060\012O\060\012O\062\012O\062\012O\062\012O\062"
  "\012O\062\012O\062\012O\062\012O\062\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\011"
  "N\061\011N\061\011N/\011N/\011N/\011N/\011N/\011N/\030Y;\030Y;\030Y;\030Y;\030Y;\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Y=\027Y=\027Y=\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024"
  "V:\024V:\024V:\023U\071\023U\071\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020S\064\020S\064\020"
  "S\064\020S\064\020S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013P\061\013P\061"
  "\013P\061\013P\061\013P\061\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\012"
  "O\060\012O\060\011N/\011N/\011N/\011N/\011N/\011N/\011N/\011N\061\011N\061\011N\061\011N\061"
  "\011N\061\011N\061\030Y;\030Y;\030Y;\030Y;\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Y=\027Y=\027Y=\027"
  "Y=\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\023U\071"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020S\064\020S\064\020S\064\020S\064\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\012"
  "O\060\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\011N/"
  "\011N/\011N/\011N/\011N/\011N/\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\030Y;"
  "\030Y;\030Y;\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Y=\027Y=\027Y=\027Y=\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\020S\064\020S\064\020S\064\020S\064\016S\064\016S\064\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013"
  "P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\012O\060\012O\060"
  "\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\011N/\011N/\011N/\011"
  "N/\011N\061\011N\061\011N\061\011N\061\011N\061\011N\061\030Y;\030Y;\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Y=\027Y=\027Y=\027Y=\027Y=\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020"
  "S\064\020S\064\020S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061"
  "\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\012O\060\012O\060\012O\060\012"
  "O\060\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\011N/\011N/\011N\061\011N\061\011"
  "N\061\011N\061\011N\061\011N\061\030Y;\030Y;\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Y=\027"
  "Y=\027Y=\027Y=\027Y=\027Y=\027Y=\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013"
  "P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\012O\060\012O\060\012O\060\012O\060"
  "\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\012O\062\011N\061\011N\061\011N\061\011"
  "N\061\011N\061\030Y;\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Y=\027Y=\027Y=\027Y=\027"
  "Y=\027Y=\027Y=\027Y=\027Y=\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061"
  "\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\012O\060\012O\060\012"
  "O\060\012O\060\012O\060\012O\060\012O\062\012O\062\012O\062\011N\061\011N\061\011N\061\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026X<\026X<\026X<\026X<\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\017T\065\017T\065\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\014Q\062\014Q\062\013P\061\013P\061"
  "\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\012O\060\012O\060\012"
  "O\060\012O\060\012O\060\012O\060\012O\060\011N/\011N/\011N/\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026"
  "Y:\026Y:\026Y:\026Y:\026Y:\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\017T\065\017T\065\017T\065\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\013P\061\013P\061\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013P\061"
  "\013P\061\013P\061\013P\061\013P\061\013P\061\012O\060\012O\060\012O\060\012O\060\012O\060\012"
  "O\060\012O\060\012O\060\011N/\011N/\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z"
  "<\031Z<\031Z<\031Z<\031Z<\031Z<\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W"
  "\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\021T\065\021T\065\021T\065\021T\065\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064"
  "\020S\064\020S\064\020S\064\017R\063\017R\063\017R\063\015R\063\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061"
  "\013P\061\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013"
  "P\061\013P\061\013P\061\013P\061\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060"
  "\012O\060\012O\060\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026X<\026X<"
  "\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021"
  "T\065\021T\065\021T\065\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064"
  "\020S\064\020S\064\017R\063\017R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013"
  "P\061\013P\061\013P\061\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060\012O\060"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024"
  "V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W"
  "\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064"
  "\020S\064\017R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013P\061\013P\061\013"
  "P\061\013P\061\013P\061\013P\061\013P\061\012O\060\012O\060\012O\060\012O\060\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013P\061\013P\061\013"
  "P\061\013P\061\013P\061\013P\061\013P\061\012O\060\012O\060\031Z<\031Z<\031Z<\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061"
  "\013P\061\013P\061\013P\061\013P\061\031Z<\031Z<\032[=\032[=\032[=\032[=\032[=\032[=\032["
  "=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Y=\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024W\070\024W\070\024W\070\024W\070\024W"
  "\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\020S\064"
  "\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\016S\064\016S\064\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061"
  "\013P\061\013P\061\031Z<\031Z<\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\032[=\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Y=\027Y="
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\025X\071\025X\071\024W\070\024W\070\024W\070\024W\070\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\020S\064\020S\064"
  "\020S\064\020S\064\020S\064\020S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013P\061"
  "\031Z<\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Y=\027Y=\027Y=\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025X\071\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W"
  "\070\024W\070\025X\071\025X\071\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\020S\064\020S\064\020S\064"
  "\020S\064\020S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032"
  "Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?"
  "\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032"
  "Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?"
  "\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032"
  "Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?"
  "\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032"
  "Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?"
  "\032Z?\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032Z?\032Z?"
  "\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032"
  "Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?"
  "\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032"
  "Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?"
  "\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032"
  "Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?"
  "\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032"
  "Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026"
  "Y:\026Y:\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\032[=\032["
  "=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\033\\>\032[=\032[=\032[=\032["
  "=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032["
  "=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032Z?\032"
  "Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033\\>\033\\>\033\\>\033\\>\033"
  "\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026"
  "Y:\026Y:\026Y:\026Y:\026Y:\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\017T\065\017T\065\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\"
  ">\033\\>\033\\>\033\\>\033\\>\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026Y:\026Y:\026Y:\026"
  "Y:\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:"
  "\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065"
  "\021T\065\021T\065\017T\065\017T\065\017T\065\017T\065\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033"
  "\\>\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032["
  "=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026Y:\026Y:\026Y:\026Y:\026X<\026X<\026X<\026X<"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\017T\065\017"
  "T\065\017T\065\017T\065\017T\065\017T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\032Z?\032Z?\032Z?\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\026Y:\026Y:\026Y:\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\023U\071\023U\071\023U\071\024W\070\024W\070\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\016S\064\016S\064\016S\064\016S\064\015"
  "R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\032Z?\032"
  "Z?\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\026Y:\026Y:\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\023U\071\023U\071\024W\070\024W\070\024W\070"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\020S\064\020S\064\020S\064\020S\064\020S\064\016S\064\016S\064\016"
  "S\064\016S\064\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\032[=\032["
  "=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\033\\>\033\\>\033\\>\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024"
  "W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020S\064\020S\064\020S\064\020S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\016S\064\016S\064\016S\064\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\033\\>\033\\>\033\\>\033\\>\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020S\064\020S\064\020S\064\020"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\016S\064\016S\064"
  "\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\032[=\032[=\032[=\032[=\032[=\032[=\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032"
  "Z?\033[@\032Z?\032Z?\032Z?\032Z?\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032"
  "Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Y=\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020"
  "S\064\020S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\032[=\032[=\032[=\032[=\032[=\032[=\032Z?\032Z?\032Z?\032Z?\032Z"
  "?\033[@\033[@\033[@\032Z?\032Z?\032Z?\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?"
  "\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Y=\027Y=\027Y=\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\017T\065\017T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\032[=\032[=\032[=\032[=\032[=\032[=\032Z?\032Z?\032Z?\032"
  "Z?\033[@\033[@\033[@\033[@\032Z?\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Y=\027Y=\027Y=\027Y=\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\017T\065\017T\065\017T\065\017T\065\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\032[=\032[=\032[=\032[=\032[=\032[=\032Z?\032Z?"
  "\032Z?\032Z?\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030"
  "Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Y=\027Y=\027Y=\027Y=\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\021T\065\021T\065\021T\065\021T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017"
  "T\065\016S\064\016S\064\017T\065\017T\065\017T\065\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\032[=\032[=\032[=\032[=\032[=\032[="
  "\032Z?\032Z?\032Z?\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Y=\027Y=\027Y=\027Y=\027Y=\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W"
  "\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067"
  "\023V\067\024U\067\024U\067\024U\067\024U\067\024U\067\024U\067\024U\067\023T\066\023T\066\023"
  "T\066\023T\066\023T\066\023T\066\023T\066\022S\065\021T\065\017T\065\017T\065\017T\065\017T\065"
  "\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\032[=\032[=\032[=\032["
  "=\032[=\032[=\032Z?\032Z?\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067"
  "\023V\067\023V\067\024U\067\024U\067\024U\067\024U\067\024U\067\024U\067\024U\067\024U\067\023"
  "T\066\023T\066\023T\066\023T\066\023T\066\023T\066\023T\066\021T\065\021T\065\017T\065\017T\065"
  "\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\032Z?\032Z?\032"
  "Z?\032Z?\032Z?\032Z?\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\032Z?\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[;\032[;\032[;\032[;\032[=\032[=\032[=\032"
  "[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:"
  "\026Y:\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024"
  "V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\024W"
  "\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\020S\064\020S\064\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[;\032[;\032[;\032[;\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026X<\026X<\026X<\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\023V\067\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020S\064\020S\064\032Z?\032Z?\032"
  "Z?\032Z?\032Z?\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[;\032[;\032[;\032[;\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:"
  "\026Y:\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024"
  "V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W"
  "\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\032Z?\032Z?\032Z?\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033\\>\032[=\032[=\032[=\032[=\032[=\032[=\032["
  "=\032[;\032[;\032[;\032[;\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\026Y:\026Y:\026Y:\026Y:\026Y:\026X<\026X<\026X<\026X<\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\032Z?\032Z?\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033\\>\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032["
  "=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026Y:\026"
  "Y:\026Y:\026Y:\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025X\071\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\022U\066\022U\066\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\021T\065\021T\065\021T\065\021T\065\032Z?\032Z?\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033\\>\033\\>\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\033\\>\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026Y:\026Y:\026Y:\026Y:\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025X\071"
  "\025X\071\025X\071\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021"
  "T\065\032Z?\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\033\\>\033\\>\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\026Y:\026Y:\026Y:\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W"
  "\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\033\\>\033\\>\033\\>\032[=\032[=\032[=\032[=\032[=\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026Y:\026Y:\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\032Z?\032Z?\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033\\>\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032["
  "=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Y=\027"
  "Y=\027Y=\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\032Z?\032Z?\033[@\033["
  "@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033\\>\033\\>\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Y=\027Y=\027Y=\027Y=\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\032Z?\032Z?\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[A\033[A\033[A\033[A\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Y=\027Y=\027Y=\027Y=\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\023V\067\023V\067\022U\066\022"
  "U\066\022U\066\022U\066\032Z?\032Z?\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033["
  "@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[A\033[A\033[A\033[A\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033\\>\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032["
  "=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Y=\027Y=\027Y=\027Y=\027"
  "Y=\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\022U\066\022U\066\032Z?\032Z?\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[A\033[A\033[A\033[A\033[A\033[A"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\032Z?\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\032Z?\032Z?\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[A\033[A"
  "\033[A\033[A\033[A\033[A\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\032Z?\032Z?\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\035]B\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[A\033[A\033[A\033[A\033[A\033[A\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y="
  "\027Y=\027Y=\027Y=\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\024W\070\024W\070\023"
  "V\067\023V\067\023V\067\023V\067\032Z?\032Z?\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\035]B\035]B\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[A\033[A\033[A\033[A\033[A\033[A\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Y=\027Y=\027Y="
  "\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023"
  "V\067\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\032Z?\032Z?\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\033[@\033["
  "@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\032Z?\032Z?\032Z?"
  "\032Z?\032Z?\032Z?\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026Y:\026Y:"
  "\026Y:\026Y:\026Y:\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\026X<\026X<\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\032Z?\032Z?\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026Y:\026Y:\026Y:\026Y:\026X<\026X<\026X<\026X<"
  "\026X<\026X<\025W;\025W;\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\032Z?\032Z?\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\033[@\033["
  "@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\032Z?\032Z?"
  "\032Z?\032Z?\032Z?\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026Y:"
  "\026Y:\026Y:\026Y:\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\026X<\026X<\026X<\026"
  "X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\032Z?\032Z?\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\032Z?\032Z?\032Z?\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026Y:\026Y:\026Y:\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\032Z?\032Z?\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\033[@\033["
  "@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\032Z?\032Z?\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\026Y:\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\032Z?\032Z?\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\032Z?\032Z?\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Y=\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\032Z?\032Z?\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\033[@\033["
  "@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\032Z?\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\027Y=\027Y=\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\032Z?\032Z?\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Y=\027Y=\027Y=\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\032Z?\032Z?\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\033[@\033["
  "@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\032Z?\032Z?\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Y=\027Y=\027Y=\027Y="
  "\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\032Z?\032Z?\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\033[@\033["
  "@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\026Y:\026Y:\026Y:\026Y:\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\032Z?"
  "\032Z?\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026Y:\026Y:\026Y:\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:"
  "\024V:\024V:\024V:\024V:\032Z?\032Z?\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026Y:"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\032Z?\032Z?\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\033[@\033["
  "@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\033\\>\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z"
  "<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\032Z?"
  "\032Z?\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\033\\>\032[=\032["
  "=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\027Y=\027Y=\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\032Z?\032Z?\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\033\\>\033\\>\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\027Y=\027Y=\027Y=\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\032[=\032[=\032[=\032[=\032[="
  "\032[=\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\035]B\035]B\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:"
  "\026Y:\026Y:\025X\071\025X\071\025X\071\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\032[="
  "\032[=\032[=\032[=\032[=\032[=\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\035]B\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026Y:\026Y:\026Y:"
  "\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\025X\071\025X\071\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\032[=\032[=\032[=\032[=\032[=\032[=\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\025X\071\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\032[=\032[=\032[=\032[=\032[=\032[=\032Z?\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:"
  "\026Y:\026Y:\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\032[=\032[=\032[=\032[=\032[="
  "\032[=\032Z?\032Z?\032Z?\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033["
  "@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026Y:\026Y:\026Y:\026Y:\026Y:"
  "\026Y:\026Y:\026Y:\026Y:\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\032[=\032[=\032[="
  "\032[=\032[=\032[=\032Z?\032Z?\032Z?\032Z?\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A"
  "\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026Y:"
  "\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\032[="
  "\032[=\032[=\032[=\032[=\032[=\032Z?\032Z?\032Z?\032Z?\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\032Z?\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\032[=\032[=\032[=\032[=\032[=\032[=\032Z?\032Z?\032Z?\032Z?\032Z?\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\033[@\033[@\033[@"
  "\033[@\033[@\033[@\032Z?\032Z?\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\026Y:\026Y:\026Y:\026Y:\026Y:\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\032[=\032[=\032[=\032[=\032[=\032[=\032Z?\032Z?\032Z?\032Z?\032Z?\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033["
  "@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Y=\027Y=\027Y=\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\032[=\032[=\032[=\032[=\032[=\032[=\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\032Z?\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Y=\027Y=\027Y=\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\033\\"
  ">\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034"
  "\\A\034\\A\034\\A\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\032Z?\032Z?\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Y=\027Y=\027Y=\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033[@\033[@\033[@\033["
  "@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\A\034\\"
  "A\034\\A\034\\A\034\\A\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\032Z?\032Z?\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Y=\027Y=\027Y=\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033[@\033[@\033["
  "@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\032Z?\032Z?\032Z?\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Y=\027Y=\027Y=\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\032"
  "[=\032[=\032[=\032[=\032[=\032[=\031Z<\032[=\032[=\032[=\032[=\032[=\032[=\032[=\033\\"
  ">\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033[@\033[@\033[@\033[@\033[@\033["
  "@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\032Z?\032Z?\032Z?\032Z?\032"
  "Z?\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Y=\027Y=\027Y=\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\032[=\032[=\032[=\032"
  "[=\032[=\032[=\031Z<\031Z<\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\032Z?\032Z?\032Z?\032"
  "Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Y="
  "\027Y=\027Y=\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<"
  "\031Z<\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?"
  "\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Y=\027Y=\027Y=\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033\\>\033\\>\033\\>\033"
  "\\>\033\\>\033\\>\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\032[=\032[=\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\033"
  "\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033\\>\033\\>\033\\>\033\\>\033"
  "\\>\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032["
  "=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\033\\"
  ">\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033\\>\033\\>\033\\>\033\\>\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\033\\>\033\\"
  ">\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033\\>\033\\>\033\\>\033\\>\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\033\\>\033\\>\033\\>\033"
  "\\>\033\\>\033\\>\033\\>\033\\>\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033\\>\033\\>\033\\>\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032["
  "=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\031Z<\032[=\032[=\032[=\032[=\032[=\032[=\032[=\033\\>\033\\>\033\\>\033\\>\033\\>\033"
  "\\>\033\\>\033\\>\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032"
  "Z?\033\\>\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032["
  "=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033\\>\033\\>\033\\>\033\\>\033"
  "\\>\033\\>\033\\>\033\\>\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027X:\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>"
  "\033\\>\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027X:\027X:\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032"
  "Z?\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026"
  "Y:\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>"
  "\033\\>\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033"
  "[@\033[@\033[@\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>"
  "\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>"
  "\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>"
  "\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>"
  "\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>"
  "\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>"
  "\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027"
  "Y=\027Y=\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\033[@\033"
  "[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@\033[@"
  "\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>"
  "\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>"
  "\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>"
  "\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>"
  "\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>"
  "\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>\033\\>"
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032Z?\032Z?\032Z?\032Z?\032Z?\032"
  "Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?"
  "\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032"
  "Z?\032Z?\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032Z?\032Z?\032Z?\032Z?\032"
  "Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032Z?\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Y=\027Y=\027Y=\027Y=\027Y=\027"
  "Y=\027Y=\027Y=\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;"
  "\025W;\025W;\025W;\025W;\025W;\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025"
  "W;\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Y=\027Y=\027Y=\027Y=\027"
  "Y=\027Y=\027Y=\027Y=\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032"
  "[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[="
  "\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\032[=\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:"
  "\026Y:\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Y=\027Y=\027Y=\027Y=\027Y="
  "\027Y=\027Y=\027Y=\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026Y:\026"
  "Y:\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026Y:\026Y:\026Y:\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y="
  "\027Y=\027Y=\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<"
  "\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031"
  "Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\031Z<\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\027Y=\027Y=\027Y=\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026Y:\026Y:\026"
  "Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\027Y="
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027X:\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:"
  "\026Y:\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027X:\027X:\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;"
  "\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030"
  "Y;\030Y;\030Y;\030Y;\030Y;\030Y;\030Y;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y="
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z"
  ";\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Y="
  "\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Y=\027Y=\027Y=\027Y=\027Y=\027"
  "Y=\027Y=\027Y=\027Y=\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026Y:\026"
  "Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:"
  "\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:"
  "\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026"
  "Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\026Y:\026Y:\026Y:\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026Y:\026Y:\026Y:\026Y:"
  "\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026"
  "Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:\026Y:"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\026Y:\026Y:\026Y:\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W"
  "\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027"
  "Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y="
  "\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027"
  "Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y="
  "\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027"
  "Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\027Y=\027Y=\027Y=\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X"
  "<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\024V:\024V:\024V:\024V:\024V:\024V:\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\023V\067\023V\067\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\024U\067\024U\067\024U\067"
  "\024U\067\024U\067\024U\067\024U\067\024U\067\023T\066\023T\066\023T\066\023T\066\023T\066\023"
  "T\066\023T\066\023T\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\024V:\024V"
  ":\024V:\024V:\024V:\024V:\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023"
  "V\067\023V\067\023V\067\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\022U\066\022U\066\022U\066\022U\066\023T\066\023T\066\023T\066\023T\066\023T\066"
  "\023T\066\023T\066\023T\066\023T\066\023T\066\023T\066\023T\066\023T\066\023T\066\023T\066\023"
  "T\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\024V:\024V:\024V:\024V:\024"
  "V:\024V:\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\024V:\024V:\024V:\024V:\024V:\024V:\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\023V\067\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\024W\070\024"
  "W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\024W\070\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020S\064\020S\064\020S\064\020S\064\020S\064"
  "\020S\064\020S\064\020S\064\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\024V:\024V"
  ":\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020S\064\020S\064\020S\064"
  "\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020"
  "S\064\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064"
  "\020S\064\020S\064\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020"
  "S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064"
  "\020S\064\020S\064\020S\064\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017"
  "T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\017T\065\017T\065\017T\065\017"
  "T\065\017T\065\017T\065\017T\065\017T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\024W\070\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020S\064\020S\064\020S\064\020S\064\020S\064"
  "\020S\064\020S\064\020S\064\020S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\022U\066\022U\066\022U\066"
  "\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\022U\066\022"
  "U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\020S\064\020S\064\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020S\064\020S\064\020S\064\020S\064\020"
  "S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\021T\065\022U\066\022U\066\022U\066\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020"
  "S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064"
  "\020S\064\020S\064\020S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064"
  "\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020S\064\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\020S\064\020S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015"
  "R\063\015R\063\015R\063\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\023"
  "V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\017T\065\017T\065\017T\065\017T\065\017T\065"
  "\017T\065\017T\065\017T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\023V\067\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\017T\065\017T\065\017T\065\017"
  "T\065\017T\065\017T\065\017T\065\017T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\014S\063\014S\063\014S\063\014S\063\014S\063\014"
  "S\063\014S\063\014S\063\014S\063\014S\063\014S\063\014S\063\014S\063\014S\063\014S\063\014S\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020S\064\020S\064\020"
  "S\064\020S\064\020S\064\020S\064\020S\064\020S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\014S\063\014S\063\014S\063\014S\063\014S\063\014S\063\014S\063\014S\063\014S\063\014S\063"
  "\014S\063\014S\063\014S\063\014S\063\014S\063\014S\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\017T\065\017T\065\017T\065\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\017T\065\017T\065\017T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\017T\065\017T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\017T\065\017T\065\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\016"
  "S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\017T\065\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\017T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\022U\066\022U\066\022U\066\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020S\064\020S\064\020S\064\020"
  "S\064\020S\064\020S\064\020S\064\020S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\015R\063\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\020S\064\020S\064\020S\064\020S\064\020S\064\020"
  "S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\013P\061\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\022U\066\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064"
  "\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\015R\063\015R\063\015R\063\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\020S\064\020S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013P\061"
  "\013P\061\013P\061\013P\061\013P\061\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\020S\064\020S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020S\064\020S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013"
  "P\061\013P\061\013P\061\013P\061\013P\061\013P\061\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\020S\064\020S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061"
  "\013P\061\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020S\064\020S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061"
  "\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\020S\064\020S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013P\061\013P\061\013"
  "P\061\013P\061\013P\061\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020S\064\020"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\020S\064\020S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013P\061"
  "\013P\061\013P\061\013P\061\013P\061\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015T\064\015T\064\015T\064"
  "\015T\064\015T\064\015T\064\015T\064\015T\064\015T\064\015T\064\015T\064\015T\064\015T\064\015"
  "T\064\015T\064\015T\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\013P\061\013P\061\013P\061\013P\061\013P\061\013P\061\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\015R\063\015R\063\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\015T\064\015T\064\015T\064\015T\064\015T\064\015T\064\015T\064\015"
  "T\064\015T\064\015T\064\015T\064\015T\064\015T\064\015T\064\015T\064\015T\064\016S\064\016S\064"
  "\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\013"
  "P\061\013P\061\013P\061\013P\061\013P\061\013P\061\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\015R\063\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\017T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\017T\065\017T\065\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\016"
  "S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\017T\065\017T\065\017T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\016S\064\016S\064\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020S\064\020S\064\020S\064\020S\064\020S\064"
  "\020S\064\020S\064\020S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020S\064\020S\064\020S\064\020"
  "S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064"
  "\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\021T\065\021T\065\021T\065\022"
  "U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020"
  "S\064\020S\064\020S\064\020S\064\020S\064\020S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\021T\065\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064"
  "\020S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\017T\065\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\017T\065\017T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\017T\065\017T\065\017T\065\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020"
  "S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020"
  "S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064"
  "\020S\064\020S\064\020S\064\020S\064\020S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062"
  "\014Q\062\014Q\062\014Q\062\014Q\062\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\017T\065\017T\065\017"
  "T\065\017T\065\017T\065\017T\065\017T\065\017T\065\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065"
  "\017T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014"
  "Q\062\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\017T\065"
  "\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\014Q\062\014Q\062\014Q\062\014Q\062\014Q\062"
  "\014Q\062\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020"
  "S\064\020S\064\020S\064\020S\064\020S\064\020S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020S\064\020S\064\020S\064\020S\064\020"
  "S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064"
  "\020S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020S\064"
  "\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015"
  "R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063"
  "\015R\063\015R\063\015R\063\015R\063\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\017T\065\017T\065"
  "\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\015R\063\015R\063\015R\063\015R\063\015R\063\015R\063\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017"
  "T\065\017T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\017"
  "T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\017T\065\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\017T\065\017T\065\017T\065\017T\065\017T\065"
  "\017T\065\017T\065\017T\065\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016"
  "S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064"
  "\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\016S\064\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020"
  "S\064\020S\064\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020S\064"
  "\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020"
  "S\064\020S\064\020S\064\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\020S\064\020S\064\020S\064\020S\064\020S\064\020"
  "S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\020S\064\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\020S\064\020S\064"
  "\020S\064\020S\064\020S\064\020S\064\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\021T\065\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\021T\065\021T\065"
  "\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021"
  "T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\021T\065\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V"
  ":\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V"
  ":\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066"
  "\022U\066\022U\066\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022"
  "U\066\022U\066\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066"
  "\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022"
  "U\066\022U\066\022U\066\022U\066\022U\066\022U\066\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\022U\066\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\022U\066\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\024V:\024V:\024V:\024V:\024V:\025W;\025W;\025W;\025W"
  ";\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\024V:\024V:\024V:\024V:\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\024V:\024V:\024V:\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023"
  "V\067\023V\067\023V\067\024V:\024V:\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W"
  ";\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\023V\067\023"
  "V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067\023V\067"
  "\023V\067\023V\067\024V:\024V:\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024V:\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W"
  "\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W"
  ";\025W;\025W;\025W;\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070"
  "\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024"
  "W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\024W\070\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\025W;\025W;\025W;\025W;\025W;\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\025W;\025W;\025W;\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\025W;\025W;\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\025W;\025W;\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\025W;\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\024V:\024V:\024V:\024"
  "V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:"
  "\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\024V:\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\027Y=\027"
  "Y=\027Y=\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\027Y=\027Y=\027Y=\027Y=\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\027Y=\027Y=\027Y=\027Y=\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Y=\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\027Y=\027Y=\027"
  "Y=\027Y=\027Y=\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Y=\027Y=\027Y=\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Y=\027Z;\027Z;"
  "\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027Z;\027"
  "Y=\027Y=\027Y=\027Y=\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026"
  "X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<"
  "\026X<\026X<\026X<\026X<\026X<\026X<\026X<\026X<\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;"
  "\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025W;\025"
  "W;",
};

//--------------------------------------------------------------------------

int cubos[altoMapa][largoMapa][2];


void parseCubos()
{   
    initX = -(tamCubo*largoMapa)/2.0;
    initZ = -(tamCubo*altoMapa)/2.0;
   
    for(int i=0;i<altoMapa;i++){
        for(int j=0;j<largoMapa;j++){
            cubos[i][j][0] = initX+(tamCubo*j);
            cubos[i][j][1] = initZ+(tamCubo*i);
            if(mapa[i][j]==2){
                posZ=i;
                posX=j;
                xActual = initX+(tamCubo*j);
                zActual = initZ+(tamCubo*i);
            }
        }
    }

    //Definimos la distancia de la cámara/foco según el tamaño del mapa
    double w = (largoMapa/2.0);
    double h = (altoMapa/2.0);
    int hipotenusa = (ceil(sqrt(w*w + h*h))+2) * tamCubo;
    camX = light_position[0] = 0.0f;
    camY = light_position[1] = minCamY;
    camZ = light_position[2] = hipotenusa;
  
}

void reshape(int width, int height) 
{
    glViewport(0, 0, width, height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    
    gluPerspective(100.0,width/height,10,maxi);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
	
}

//textuturas--------------------------------------------------------
void define_textura_2D_128(struct ttextura_gimp textuN)
{
	glGenTextures(1,&textureID);   				// Genera la textura 1 con la variable texture
	glBindTexture(GL_TEXTURE_2D,textureID);		// Asocia la variable texture como GL_TEXTURE_2D
	glTexEnvf( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);  // Asigna Gl_MODULATE A GL_TEXTURE_ENV_MODE
	gluBuild2DMipmaps( GL_TEXTURE_2D, textuN.bytes_per_pixel,textuN.width,textuN.height,GL_RGB,GL_UNSIGNED_BYTE,textuN.pixel_data );
		// Define las propiedasdes de la textura 2D asociando la textura exportada gimp_image a la GL_TEXTURE_2D
};

//------------------------------------------------------------------
void dibujarCubo(int X, int Z){

    
    glColor4f(1.0,1.0,1.0,1.0);
        
       
        
    glBegin(GL_QUADS);
        //Cara de enfrente
        glNormal3f(0.0f, 0.0f, 1.0f);
        glTexCoord2d(0.0,0.0);   glVertex3f(X-espacios,espacios,Z+espacios);
        glTexCoord2d(0.0,1.0);   glVertex3f(X-espacios,-espacios,Z+espacios);
        glTexCoord2d(1.0,1.0);   glVertex3f(X+espacios,-espacios,Z+espacios);
        glTexCoord2d(1.0,0.0);   glVertex3f(X+espacios,espacios,Z+espacios);
        
  

        //Cara izquierda
        glNormal3f(-1.0f, 0.0f, 0.0f);
        glTexCoord2d(0.0,0.0);   glVertex3f(X-espacios,espacios,Z-espacios);
        glTexCoord2d(0.0,1.0);   glVertex3f(X-espacios,-espacios,Z-espacios);
        glTexCoord2d(1.0,1.0);   glVertex3f(X-espacios,-espacios,Z+espacios);
        glTexCoord2d(1.0,0.0);   glVertex3f(X-espacios,espacios,Z+espacios);

        //Cara de atrás
        glNormal3f(0.0f, 0.0f, -1.0f);
        glTexCoord2d(0.0,0.0);   glVertex3f(X+espacios,espacios,Z-espacios);
        glTexCoord2d(0.0,1.0);   glVertex3f(X+espacios,-espacios,Z-espacios);
        glTexCoord2d(1.0,1.0);   glVertex3f(X-espacios,-espacios,Z-espacios);
        glTexCoord2d(1.0,0.0);   glVertex3f(X-espacios,espacios,Z-espacios);

        //Cara derecha
        glNormal3f(1.0f, 0.0f, 0.0f);
        glTexCoord2d(0.0,0.0);   glVertex3f(X+espacios,espacios,Z+espacios);
        glTexCoord2d(0.0,1.0);   glVertex3f(X+espacios,-espacios,Z+espacios);
        glTexCoord2d(1.0,1.0);   glVertex3f(X+espacios,-espacios,Z-espacios);
        glTexCoord2d(1.0,0.0);   glVertex3f(X+espacios,espacios,Z-espacios);

        //Cara Arriba
        glNormal3f(0.0f, 1.0f, 0.0f);
        glTexCoord2d(0.0,0.0);   glVertex3f(X-espacios,espacios,Z-espacios);
        glTexCoord2d(0.0,1.0);   glVertex3f(X-espacios,espacios,Z+espacios);
        glTexCoord2d(1.0,1.0);   glVertex3f(X+espacios,espacios,Z+espacios);
        glTexCoord2d(1.0,0.0);   glVertex3f(X+espacios,espacios,Z-espacios);
    glEnd();
   
}

//colision
bool esValido(int X, int Z) {
    return X>=0 && X<largoMapa && Z>=0 && Z<altoMapa;
    
}



void piso(int X, int Y, int Z){
    glPushMatrix();
    glColor3f(0,1,0);

    glBegin(GL_QUADS);
        glNormal3f(0.0f, 1.0f, 0.0f); //Hacia arriba
        glVertex3f(X-espacios,Y,Z-espacios);
        glVertex3f(X-espacios,Y,Z+espacios);
        glVertex3f(X+espacios,Y,Z+espacios);
        glVertex3f(X+espacios,Y,Z-espacios);
    glEnd();
    glColor3f(1,1,1);
    glPopMatrix();


}

//dibujamos la figura a mover
void figuraLapiz()
{
	//punta del lapiz
	glPushMatrix();
		glColor3f(1,1,1);
		glTranslatef(xActual,10+flt,zActual);
		glRotatef(90,1,0,0);
		glutSolidCone(10, 20, 40, 40);
	glPopMatrix();
	
	//cuerpo del lapiz
	glPushMatrix();
		glColor3f(1,1,0);
		glTranslatef(xActual,tamCubo+flt,zActual);
		//~ glRotatef(rotx,1,0,0);
		//~ glRotatef(roty,0,1,0);
    glutSolidCube(tamCubo);
	glPopMatrix();
		//	
	glPushMatrix();
		glColor3f(1,1,0);
		glTranslatef(xActual,(tamCubo*2)+flt,zActual);
		glutSolidCube(tamCubo);
	glPopMatrix();
	//borrador
	glPushMatrix();
		glColor3f(1,0.5,1);
		glTranslatef(xActual,(tamCubo*3)+flt,zActual);
		glutSolidCube(tamCubo);
	glPopMatrix();
	//cubo blanco oculto para que no se manche todo alv
		glPushMatrix();
		glColor3f(1,1,1);
		glTranslatef(xActual,(tamCubo*2)+flt,zActual);
		glutSolidCube(2);
	glPopMatrix();
}

//dibujamos los cubos mediante funciones
void cuboA(int i, int j)
{
	glPushMatrix();
                    glColor3f(0,1,0);
                    glTranslatef(cubos[i][j][0],lA,cubos[i][j][1]);
                    glTranslatef(0,lA,0);
                    glutSolidCube(tamCubo);
    glPopMatrix();
}

void cuboT(int i, int j)
{
	 glPushMatrix();
                    glColor3f(1,0,1);
                    glTranslatef(cubos[i][j][0],lT,cubos[i][j][1]);
                    glutSolidCube(tamCubo);
     glPopMatrix();
}

void cuboL(int i, int j)
{
	 glPushMatrix();
                    glColor3f(1,1,0);
                    glTranslatef(cubos[i][j][0],lL,cubos[i][j][1]);
                    glutSolidCube(tamCubo);
     glPopMatrix();
}

void cuboP(int i, int j)
{
	 glPushMatrix();
                     glColor3f(1,0.5,0);
                    glTranslatef(cubos[i][j][0],lP,cubos[i][j][1]);
                    glutSolidCube(tamCubo);
     glPopMatrix();
}

void cuboN(int i, int j)
{
	 glPushMatrix();
                    glColor3f(0,0,1);
                    glTranslatef(cubos[i][j][0],lN,cubos[i][j][1]);
                    glutSolidCube(tamCubo);
     glPopMatrix();
}

void cuboK(int i, int j)
{
	 glPushMatrix();
                     glColor3f(0,0.5,0.5);
                    glTranslatef(cubos[i][j][0],lK,cubos[i][j][1]);
                    glutSolidCube(tamCubo);
     glPopMatrix();
}

void cuboO(int i, int j)
{
	 glPushMatrix();
                    glColor3f(0,1,1);
                    glTranslatef(cubos[i][j][0],lO,cubos[i][j][1]);
                    glutSolidCube(tamCubo);
     glPopMatrix();
}

void cuboI(int i, int j)
{
	 glPushMatrix();
                   glColor3f(1,0,0);
                    glTranslatef(cubos[i][j][0],lI,cubos[i][j][1]);
                    glutSolidCube(tamCubo);
     glPopMatrix();
}

void cuboM(int i, int j)
{
	 glPushMatrix();
                   glColor3f(0.5,0.5,1);;
                    glTranslatef(cubos[i][j][0],lM,cubos[i][j][1]);
                    glutSolidCube(tamCubo);
     glPopMatrix();
}

void cuboS(int i, int j)
{
	 glPushMatrix();
                    glColor3f(1,1,0.5);
                    glTranslatef(cubos[i][j][0],lS,cubos[i][j][1]);
                    glutSolidCube(tamCubo);
     glPopMatrix();
}

void cuboH(int i, int j)
{
	 glPushMatrix();
	 
                   glColor3f(0.5,0.5,0.5);
                    glTranslatef(cubos[i][j][0],lH,cubos[i][j][1]);
                    glutSolidCube(tamCubo);
     glPopMatrix();
}

void cuboC(int i, int j)
{	
	 glPushMatrix();
                    glColor3f(1,0.5,0.5);
                    glTranslatef(cubos[i][j][0],lC,cubos[i][j][1]);
                    glutSolidCube(tamCubo);
     glPopMatrix();
}

void cuboE(int i, int j)
{	
	 glPushMatrix();
                    glColor3f(0,0,0);
                    glTranslatef(cubos[i][j][0],lE,cubos[i][j][1]);
                    glutSolidCube(tamCubo);
     glPopMatrix();
}

void cuboY(int i, int j)
{
	 glPushMatrix();
                    glColor3f(0.5,1,0.5);
                    glTranslatef(cubos[i][j][0],lY,cubos[i][j][1]);
                    glutSolidCube(tamCubo);
     glPopMatrix();
}

//--MAPA---------------------------------------------------------------

void dibujaMapa(){
	//float x,y;
	
  define_textura_2D_128(textura_verde);
	for(int i=0;i<altoMapa;i++){
        for(int j=0;j<largoMapa;j++){
            switch(mapa[i][j]){
                case 0:
                case 2:
                    piso(cubos[i][j][0],-espacios,cubos[i][j][1]);
                    break;
                case 1:
                     //Carga el cubo con textura
                    glEnable(GL_TEXTURE_2D);		// Habilita la GL_TEXTURE_2D
                    glPushMatrix();
                    dibujarCubo(cubos[i][j][0],cubos[i][j][1]);
                    glDisable(GL_TEXTURE_2D);
                    glPopMatrix();

                break;
                case 5:
                
                    cuboA(i,j);
             
                break;
                
				case 6:
                   cuboT(i,j);

                break;
                
                case 7:
                   cuboL(i,j);

                break;
                
                case 8:
                  cuboP(i,j);

                break;
                
                case 9:
                   cuboN(i,j);

                break;
                
                case 10:
                   cuboK(i,j);
                break;
                
                case 11:
                   cuboO(i,j);

                break;
                
                case 12:
                   cuboI(i,j);

                break;
                
                case 13:
                  cuboM(i,j);

                break;
                
                case 14:
                   cuboS(i,j);

                break;
                
                case 15:
                   cuboH(i,j);

                break;
                
                case 16:
                  cuboC(i,j);

                break;
                
                case 17:
                  cuboE(i,j);

                break;
                
                case 18:
                  cuboY(i,j);

                break;
                                
                case 3:
                    glPushMatrix();
                    glColor3f(0,0,1);
                    glTranslatef(cubos[i][j][0],0,cubos[i][j][1]);
                    glutSolidCube(tamCubo);
                    glPopMatrix();
                break;
            }
        }
    }
		//llamamos a la funcion apra dibujar el lapiz
	figuraLapiz();
}
void dibujaMapa2(){
	//float x,y;
	
  define_textura_2D_128(textura_verde);
	for(int i=0;i<altoMapa;i++){
        for(int j=0;j<largoMapa;j++){
            switch(mapa2[i][j]){
                case 0:
                case 2:
                    piso(cubos[i][j][0],-espacios,cubos[i][j][1]);
                    break;
                case 1:
                     //Carga el cubo con textura
                    glEnable(GL_TEXTURE_2D);		// Habilita la GL_TEXTURE_2D
                    glPushMatrix();
                    dibujarCubo(cubos[i][j][0],cubos[i][j][1]);
                    glDisable(GL_TEXTURE_2D);
                    glPopMatrix();

                break;
                
                case 5:
                
                    cuboA(i,j);
             
                break;
                
				case 6:
                   cuboT(i,j);

                break;
                
                case 7:
                   cuboL(i,j);

                break;
                
                
            }
        }
    }
		//llamamos a la funcion apra dibujar el lapiz
		figuraLapiz();
}
void dibujaMapa3(){
	//float x,y;
	
  define_textura_2D_128(textura_verde);
	for(int i=0;i<altoMapa;i++){
        for(int j=0;j<largoMapa;j++){
            switch(mapa3[i][j]){
                case 0:
                case 2:
                    piso(cubos[i][j][0],-espacios,cubos[i][j][1]);
                    break;
                case 1:
                     //Carga el cubo con textura
                    glEnable(GL_TEXTURE_2D);		// Habilita la GL_TEXTURE_2D
                    glPushMatrix();
                    dibujarCubo(cubos[i][j][0],cubos[i][j][1]);
                    glDisable(GL_TEXTURE_2D);
                    glPopMatrix();

                break;
                
                case 5:
                
                    cuboA(i,j);
             
                break;
                
				 case 8:
                  cuboP(i,j);

                break;
                
                case 9:
                   cuboN(i,j);

                break;
                
                
            }
        }
    }
		//llamamos a la funcion apra dibujar el lapiz
		figuraLapiz();
}
void dibujaMapa4(){
	//float x,y;
	
  define_textura_2D_128(textura_verde);
	for(int i=0;i<altoMapa;i++){
        for(int j=0;j<largoMapa;j++){
            switch(mapa4[i][j]){
                case 0:
                case 2:
                    piso(cubos[i][j][0],-espacios,cubos[i][j][1]);
                    break;
                case 1:
                     //Carga el cubo con textura
                    glEnable(GL_TEXTURE_2D);		// Habilita la GL_TEXTURE_2D
                    glPushMatrix();
                    dibujarCubo(cubos[i][j][0],cubos[i][j][1]);
                    glDisable(GL_TEXTURE_2D);
                    glPopMatrix();

                break;
                
                
                
                case 5:
                
                    cuboA(i,j);
             
                break;
                
				case 6:
                   cuboT(i,j);

                break;
                
                case 11:
                   cuboO(i,j);

                break;
                
                case 12:
                  cuboI(i,j);

                break;
                
                case 9:
                   cuboN(i,j);

                break;
                
               
            }
        }
    }
		//llamamos a la funcion apra dibujar el lapiz
		figuraLapiz();
}
void dibujaMapa5(){
	//float x,y;
	
  define_textura_2D_128(textura_verde);
	for(int i=0;i<altoMapa;i++){
        for(int j=0;j<largoMapa;j++){
            switch(mapa5[i][j]){
                case 0:
                case 2:
                    piso(cubos[i][j][0],-espacios,cubos[i][j][1]);
                    break;
                case 1:
                     //Carga el cubo con textura
                    glEnable(GL_TEXTURE_2D);		// Habilita la GL_TEXTURE_2D
                    glPushMatrix();
                    dibujarCubo(cubos[i][j][0],cubos[i][j][1]);
                    glDisable(GL_TEXTURE_2D);
                    glPopMatrix();

                break;
                
                
				case 6:
                   cuboT(i,j);

                break;
                
                case 7:
                   cuboL(i,j);

                break;
                
                case 12:
                   cuboI(i,j);

                break;
                
                case 13:
                  cuboM(i,j);

                break;
                
                case 14:
                   cuboS(i,j);

                break;
                
                case 15:
                   cuboH(i,j);

                break;
                
                
            }
        }
    }
		//llamamos a la funcion apra dibujar el lapiz
		figuraLapiz();
}
void dibujaMapa6(){
	//float x,y;
	
  define_textura_2D_128(textura_verde);
	for(int i=0;i<altoMapa;i++){
        for(int j=0;j<largoMapa;j++){
            switch(mapa6[i][j]){
                case 0:
                case 2:
                    piso(cubos[i][j][0],-espacios,cubos[i][j][1]);
                    break;
                case 1:
                     //Carga el cubo con textura
                    glEnable(GL_TEXTURE_2D);		// Habilita la GL_TEXTURE_2D
                    glPushMatrix();
                    dibujarCubo(cubos[i][j][0],cubos[i][j][1]);
                    glDisable(GL_TEXTURE_2D);
                    glPopMatrix();

                break;
                
                
				 
                case 5:
                
                    cuboA(i,j);
             
                break;
                
				case 6:
                   cuboT(i,j);

                break;
                
                case 7:
                   cuboL(i,j);

                break;
                
               
                case 9:
                   cuboN(i,j);

                break;
                
                case 10:
                   cuboK(i,j);
                break;
                
                case 11:
                   cuboO(i,j);

                break;
                
                case 12:
                   cuboI(i,j);

                break;
                
                
                case 14:
                   cuboS(i,j);

                break;
                
                case 15:
                   cuboH(i,j);

                break;
                
                case 16:
                  cuboC(i,j);

                break;
                
                
            }
        }
    }
		//llamamos a la funcion apra dibujar el lapiz
		figuraLapiz();
}
void dibujaMapa7(){
	//float x,y;
	
  define_textura_2D_128(textura_verde);
	for(int i=0;i<altoMapa;i++){
        for(int j=0;j<largoMapa;j++){
            switch(mapa7[i][j]){
                case 0:
                case 2:
                    piso(cubos[i][j][0],-espacios,cubos[i][j][1]);
                    break;
                case 1:
                     //Carga el cubo con textura
                    glEnable(GL_TEXTURE_2D);		// Habilita la GL_TEXTURE_2D
                    glPushMatrix();
                    dibujarCubo(cubos[i][j][0],cubos[i][j][1]);
                    glDisable(GL_TEXTURE_2D);
                    glPopMatrix();

                break;
                
				case 6:
                   cuboT(i,j);

                break;
                
                case 7:
                   cuboL(i,j);

                break;
                
                case 11:
                   cuboO(i,j);

                case 18:
                  cuboY(i,j);

                break;
                
                
            }
        }
    }
		//llamamos a la funcion apra dibujar el lapiz
		figuraLapiz();
}
void dibujaMapa8(){
	//float x,y;
	
  define_textura_2D_128(textura_verde);
	for(int i=0;i<altoMapa;i++){
        for(int j=0;j<largoMapa;j++){
            switch(mapa8[i][j]){
                case 0:
                case 2:
                    piso(cubos[i][j][0],-espacios,cubos[i][j][1]);
                    break;
                case 1:
                     //Carga el cubo con textura
                    glEnable(GL_TEXTURE_2D);		// Habilita la GL_TEXTURE_2D
                    glPushMatrix();
                    dibujarCubo(cubos[i][j][0],cubos[i][j][1]);
                    glDisable(GL_TEXTURE_2D);
                    glPopMatrix();

                break;
                
                case 5:
                
                    cuboA(i,j);
             
                break;
                
				case 6:
                   cuboT(i,j);

                break;
                
                case 7:
                   cuboL(i,j);

                break;
                
                case 10:
                   cuboK(i,j);
                break;
                
                case 13:
                  cuboM(i,j);

                break;
                
                case 17:
                  cuboE(i,j);

                break;
                
            }
        }
    }
		//llamamos a la funcion apra dibujar el lapiz
		figuraLapiz();
}
void dibujaMapa9(){
	//float x,y;
	
  define_textura_2D_128(textura_verde);
	for(int i=0;i<altoMapa;i++){
        for(int j=0;j<largoMapa;j++){
            switch(mapa9[i][j]){
                case 0:
                case 2:
                    piso(cubos[i][j][0],-espacios,cubos[i][j][1]);
                    break;
                case 1:
                     //Carga el cubo con textura
                    glEnable(GL_TEXTURE_2D);		// Habilita la GL_TEXTURE_2D
                    glPushMatrix();
                    dibujarCubo(cubos[i][j][0],cubos[i][j][1]);
                    glDisable(GL_TEXTURE_2D);
                    glPopMatrix();

                break;
               
                
				case 6:
                   cuboT(i,j);

                break;
                
                case 7:
                   cuboL(i,j);

                break;
                
                case 12:
                   cuboI(i,j);

                break;
                
                case 13:
                  cuboM(i,j);

                break;
                
                case 14:
                   cuboS(i,j);

                break;
                
                case 17:
                  cuboE(i,j);

                break;
                
               
            }
        }
    }
		//llamamos a la funcion apra dibujar el lapiz
		figuraLapiz();
}

//Funcion para limpiar el arreglo
void limpiar_Arreglo()
{
	for(int i=0; i<20; i++)
	{
		palabra[i] = '\0';
	}
}

void mostrar_texto()
{
	textoA(E);
	textoT(E);
	textoL(E);
	textoP(E);
	textoN(E);
	textoK(E);
	textoO(E);
	textoI(E);
	textoM(E);
	textoS(E);
	textoH(E);
	textoC(E);
	textoE(E);
	textoY(E);
}
// función que muestra por pantalla la escena.
void display() {
    
		//---PALBRA  1-------
	if(rc==0)//mostramos la palabra a completar
	{
		SDL_PauseAudio(1);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glLoadIdentity();
		gluLookAt(camX,camY,camZ,0,0,0,camX,camY+1,camZ);
		glLightfv(GL_LIGHT0, GL_POSITION, light_position);
		textoPresione3(E);
		imagenAGUA();
		dibujaMapa2();
		glutSwapBuffers();
	}
	
	if(rc==1)//cambiamos la vista para comenzar el juego
	{
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glLoadIdentity();
	   
		textoScore(E);
		textoTiempo(E);
		textoATL(E);
		textoLetras(E);
		
		mostrar_texto();
		  
		 //colision-----------
		if(validacion==0 && mapa[posZ][posX]==5)
		{
			puntos+=5, validacion++, lA=-30, palabra[0]='A';
		}
		
		//colision 
		if(validacion==1 && mapa[posZ][posX]==6)
		{
			puntos+=5, validacion++,lT=-30, palabra[1]='T'; 
		}
		if(validacion==2 && mapa[posZ][posX]==7)
		{
			puntos+=5, validacion++,lL=-30, palabra[2]='L';
		}
		
		if(validacion==3)
		{
			rc=3, lA=0,lT=0,lL=0;	
			limpiar_Arreglo();
		}	
		
		gluLookAt(camX,camY,camZ,0,0,0,camX,camY+1,camZ);
		glLightfv(GL_LIGHT0, GL_POSITION, light_position);
				
		dibujaMapa2();
		glutSwapBuffers();
	}


 	//--------PALABRA 2--------RIO-----------------------------------------------------
	
	if (rc==3)//mostramos la palabra
	{	
		SDL_PauseAudio(1);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glLoadIdentity();
		
		if(camY>minCamY){camY-=300;}
		
		gluLookAt(camX,camY,camZ,0,0,0,camX,camY+1,camZ);
		glLightfv(GL_LIGHT0, GL_POSITION, light_position);
		
		textoPresione3(E);
		
		imagenRIO();
		
		dibujaMapa3();
		glutSwapBuffers();
	}
	if (rc==4)//cambiamos la vista
	{
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glLoadIdentity();
	   
		//puntucion, otros
		textoScore(E);
		textoTiempo(E);
		textoAPAN(E);
		textoLetras(E);
		 
		mostrar_texto();
		  
		 //colision-----------
		if(validacion==3 && mapa[posZ][posX]==5)
		{
			puntos+=5, validacion++, lA=-30, palabra[0]='A';
		}
		if(validacion==4 && mapa[posZ][posX]==8)
		{
			puntos+=5, validacion++, lP=-30,lA=0,palabra[1]='P';
		}
		if(validacion==5 && mapa[posZ][posX]==5)
		{
			puntos+=5, validacion++, lA=-30,palabra[2]='A';
		}
		if(validacion==6 && mapa[posZ][posX]==9)
		{
			puntos+=5, validacion++,lN=-30,palabra[3]='N';
		}
		
		if(validacion==7)
		{
			rc=5,lA=0, lP=0, lN=0;
			limpiar_Arreglo();
		}	
		
		gluLookAt(camX,camY,camZ,0,0,0,camX,camY+1,camZ);
		glLightfv(GL_LIGHT0, GL_POSITION, light_position);
			
		dibujaMapa3();
		glutSwapBuffers();
	 }
 

	//--------PALABRA 3-------SOL---------------------------------------------------
	
	if (rc==5)//mostramos la palabra
	{
		
		SDL_PauseAudio(1);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glLoadIdentity();
		
		if(camY>minCamY){camY-=300;}
		
		gluLookAt(camX,camY,camZ,0,0,0,camX,camY+1,camZ);
		glLightfv(GL_LIGHT0, GL_POSITION, light_position);
		
		textoPresione3(E);
		
		imagenSOL();
		
		dibujaMapa4();
		glutSwapBuffers();
	}
	if (rc==6)//cambiamos la vista
	{
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glLoadIdentity();
	   
		//puntucion, otros
		textoScore(E);
		textoTiempo(E);
		textoTONATI(E);
		textoLetras(E);
		 
		mostrar_texto();
		 
		 //colision-----------
		if(validacion==7 && mapa[posZ][posX]==6)
		{
			puntos+=5, validacion++,lT=-30, palabra[0]='T';
		}
		if(validacion==8 && mapa[posZ][posX]==11)
		{
			puntos+=5, validacion++, lO=-30, palabra[1]='O';
		}
		if(validacion==9 && mapa[posZ][posX]==9)
		{
			puntos+=5, validacion++, lN=-30, palabra[2]='N';
		}
		if(validacion==10 && mapa[posZ][posX]==5)
		{
			puntos+=5, validacion++,lA=-30,lT=0, palabra[3]='A';
		}
		if(validacion==11 && mapa[posZ][posX]==6)
		{
			puntos+=5, validacion++, lT=-30, palabra[4]='T';
		}
		if(validacion==12 && mapa[posZ][posX]==12)
		{
			puntos+=5, validacion++;
		}
		   
		if(validacion==13)
		{
			rc=7, lT=0, lO=0, lN=0,lA=0;
			limpiar_Arreglo();
		}	
		
		gluLookAt(camX,camY,camZ,0,0,0,camX,camY+1,camZ);
		glLightfv(GL_LIGHT0, GL_POSITION, light_position);
			
		dibujaMapa4();
		glutSwapBuffers();
	}
   
   
   	//--------PALABRA 4----------------------------------------------------------
	
	if (rc==7)//mostramos la palabra
	{
		
		SDL_PauseAudio(1);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glLoadIdentity();
		
		if(camY>minCamY)
		{
			camY-=300;
		}
		
		gluLookAt(camX,camY,camZ,0,0,0,camX,camY+1,camZ);
		glLightfv(GL_LIGHT0, GL_POSITION, light_position);
		
		textoPresione3(E);
		
		imagenNUBE();
		
		dibujaMapa5();
		glutSwapBuffers();
		
	}
	if (rc==8)//cambiamos la vista
	{
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glLoadIdentity();
	   
		//puntucion, otros
		textoScore(E);
		textoTiempo(E);
		textoNUBE(E);
		textoLetras(E);
		 
		mostrar_texto();
		  
		//colision-----------
		if(validacion==13 && mapa[posZ][posX]==13)
		{
			puntos+=5, validacion++,lM=-30, palabra[0]='M';
		}
		if(validacion==14 && mapa[posZ][posX]==12)
		{
			puntos+=5, validacion++,  lI=-30,palabra[1]='I';
		}
		if(validacion==15 && mapa[posZ][posX]==14)
		{
			puntos+=5, validacion++, lS=-30, palabra[2]='S';
		}
		if(validacion==16 && mapa[posZ][posX]==15)
		{
			puntos+=5, validacion++,lH=-30, palabra[3]='H';
		}
		if(validacion==17 && mapa[posZ][posX]==6)
		{
			puntos+=5, validacion++,lT=-30, palabra[4]='T';
		}
		if(validacion==18 && mapa[posZ][posX]==7)
		{
			puntos+=5, validacion++,lL=-30, lI=0, palabra[5]='L';
		}
		if(validacion==19 && mapa[posZ][posX]==12)
		{
			puntos+=5, validacion++;
		}
		
		if(validacion==20)
		{
			rc=9;
			lM=0,lI=0,lS=0,lH=0,lT=0,lL=0,lI=0;
			limpiar_Arreglo();
			
		}	
		gluLookAt(camX,camY,camZ,0,0,0,camX,camY+1,camZ);
		glLightfv(GL_LIGHT0, GL_POSITION, light_position);
			
		dibujaMapa5();
		glutSwapBuffers();
	}
    
     
  	//--------PALABRA 5-------------------------------------------------------------------
	
	if (rc==9)//mostramos la palabra
	{
		
		SDL_PauseAudio(1);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glLoadIdentity();
		
		 if(camY>minCamY){camY-=300;}
		
		gluLookAt(camX,camY,camZ,0,0,0,camX,camY+1,camZ);
		glLightfv(GL_LIGHT0, GL_POSITION, light_position);
		
		textoPresione3(E);
		
		imagenHONGO();
		
		dibujaMapa();
		glutSwapBuffers();
		
	}
	if (rc==10)//cambiamos la vista
	{
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glLoadIdentity();
	   
		//puntucion, otros
		textoScore(E);
		textoTiempo(E);
		textoHONGO(E);
		textoLetras(E);
		 
		mostrar_texto();
		  
		//colision-----------
		if(validacion==20 && mapa[posZ][posX]==14)
		{
			puntos+=5, validacion++, lS=-30,palabra[0]='S';
		}
		if(validacion==21 && mapa[posZ][posX]==15)
		{
			puntos+=5, validacion++, lH=-30,palabra[1]='H';
		}
		if(validacion==22 && mapa[posZ][posX]==11)
		{
			puntos+=5, validacion++, lO=-30, palabra[2]='O';
		}
		if(validacion==23 && mapa[posZ][posX]==16)
		{
			puntos+=5, validacion++,lH=0, lC=-30, palabra[3]='C';
		}
		if(validacion==24 && mapa[posZ][posX]==15)
		{
			puntos+=5, validacion++, lH=-30, palabra[4]='H';
		}
		if(validacion==25 && mapa[posZ][posX]==12)
		{
			puntos+=5, validacion++,lI=-30,palabra[5]='I';
		}
		if(validacion==26 && mapa[posZ][posX]==9)
		{
			puntos+=5, validacion++, lN=-30, palabra[6]='N';
		}
		if(validacion==27 && mapa[posZ][posX]==5)
		{
			puntos+=5, validacion++,lN=0,lA=-30, palabra[7]='A';
		}
		if(validacion==28 && mapa[posZ][posX]==9)
		{
			puntos+=5, validacion++, lN=-30, lA=0, palabra[8]='N';
		}
		if(validacion==29 && mapa[posZ][posX]==5)
		{
			puntos+=5, validacion++, lA=-30, palabra[9]='A';
		}
		if(validacion==30 && mapa[posZ][posX]==10)
		{
			puntos+=5, validacion++, lA=0, lK=-30,palabra[10]='K';
		}
		if(validacion==31 && mapa[posZ][posX]==5)
		{
			puntos+=5, validacion++,lA=-30,palabra[11]='A';
		}
		if(validacion==32 && mapa[posZ][posX]==6)
		{
			puntos+=5, validacion++,lT=-30,palabra[12]='T';
		}
		if(validacion==33 && mapa[posZ][posX]==7)
		{
			puntos+=5, validacion++;
		}
		
		if(validacion==34)
		{
			rc=11;
			lS=0, lH=0, lO=0, lI=0, lN=0,lA=0,lK=0,lT=0;
			limpiar_Arreglo();
		}	
		
		gluLookAt(camX,camY,camZ,0,0,0,camX,camY+1,camZ);
		glLightfv(GL_LIGHT0, GL_POSITION, light_position);		
			
		dibujaMapa();
		glutSwapBuffers();
	 }
		
	//--------PALABRA 6-------------------------------------------------------------------
	
	if (rc==11)//mostramos la palabra
	{
		SDL_PauseAudio(1);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glLoadIdentity();
		
		if(camY>minCamY)
		{
			camY-=300;
		}
		
		gluLookAt(camX,camY,camZ,0,0,0,camX,camY+1,camZ);
		glLightfv(GL_LIGHT0, GL_POSITION, light_position);
		
		textoPresione3(E);
		
		imagenCORAZON();
		
		dibujaMapa7();
		glutSwapBuffers();
	}
	if (rc==12)//cambiamos la vista
	{
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glLoadIdentity();
	   
		//puntucion, otros
		textoScore(E);
		textoTiempo(E);
		textoYOLOTL(E);
		textoLetras(E);
		 
		mostrar_texto();
		
		//colision-----------
		if(validacion==34 && mapa[posZ][posX]==18)
		{
			puntos+=5, validacion++, lY=-30, palabra[0]='Y';
		}
		if(validacion==35 && mapa[posZ][posX]==11)
		{
			puntos+=5, validacion++, lO=-30,palabra[1]='O';
		}
		if(validacion==36 && mapa[posZ][posX]==7)
		{
			puntos+=5, validacion++, lO=0, lL=-30,palabra[2]='L';
		}
		if(validacion==37 && mapa[posZ][posX]==11)
		{
			puntos+=5, validacion++, lO=-30, palabra[3]='O';
		}
		if(validacion==38 && mapa[posZ][posX]==6)
		{
			puntos+=5, validacion++, lL=0, lT=-30,palabra[4]='T';
		}
		if(validacion==39 && mapa[posZ][posX]==7)
		{
			puntos+=5, validacion++;
		}
		if(validacion==40)
		{
			rc=13;
			lY=0,lO=0, lL=0, lT=0;
			limpiar_Arreglo();
		}	
		
		gluLookAt(camX,camY,camZ,0,0,0,camX,camY+1,camZ);
		glLightfv(GL_LIGHT0, GL_POSITION, light_position);
			
		dibujaMapa7();
		glutSwapBuffers();
	 }
 
 	
	//--------PALABRA 7-------------------------------------------------------------------
	
	if (rc==13)//mostramos la palabra
	{
		SDL_PauseAudio(1);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glLoadIdentity();
		
		if(camY>minCamY)
		{
			camY-=300;
		}
		
		gluLookAt(camX,camY,camZ,0,0,0,camX,camY+1,camZ);
		glLightfv(GL_LIGHT0, GL_POSITION, light_position);
		
		textoPresione3(E);
		
		imagenCUERDA();
		
		dibujaMapa8();
		glutSwapBuffers();
		
	}
	if (rc==14)//cambiamos la vista
	{
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glLoadIdentity();
	   
		//puntucion, otros
		textoScore(E);
		textoTiempo(E);
		textoMEKATL(E);
		textoLetras(E);
		 
		mostrar_texto();
		
		//colision-----------
		if(validacion==40 && mapa[posZ][posX]==13)
		{
			puntos+=5, validacion++, lM=-30, palabra[0]='M';
		}
		if(validacion==41 && mapa[posZ][posX]==17)
		{
			puntos+=5, validacion++, lE=-30,palabra[1]='E';
		}
		if(validacion==42 && mapa[posZ][posX]==10)
		{
			puntos+=5, validacion++,lK=-30,palabra[2]='K';
		}
		if(validacion==43 && mapa[posZ][posX]==5)
		{
			puntos+=5, validacion++, lA=-30, palabra[3]='A';
		}
		if(validacion==44 && mapa[posZ][posX]==6)
		{
			puntos+=5, validacion++,lT=-30,palabra[4]='T';
		}
		if(validacion==45 && mapa[posZ][posX]==7)
		{
			puntos+=5, validacion++;
		}
		if(validacion==46)
		{
			rc=15;
			lM=0,lE=0,lK=0, lA=0, lT=0;
			limpiar_Arreglo();
		}	
		
		gluLookAt(camX,camY,camZ,0,0,0,camX,camY+1,camZ);
		glLightfv(GL_LIGHT0, GL_POSITION, light_position);
			
		dibujaMapa8();
		glutSwapBuffers();
	 }
 
 	//--------PALABRA 8-------------------------------------------------------------------
	if (rc==15)//mostramos la palabra
	{
		SDL_PauseAudio(1);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glLoadIdentity();
		if(camY>minCamY)
		{
			camY-=300;
		}
		gluLookAt(camX,camY,camZ,0,0,0,camX,camY+1,camZ);
		glLightfv(GL_LIGHT0, GL_POSITION, light_position);
		textoPresione3(E);
		imagenLUNA();
		dibujaMapa9();
		glutSwapBuffers();
	}
	if (rc==16)//cambiamos la vista
	{
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glLoadIdentity();
	   
		 //puntucion, otros
		textoScore(E);
		textoTiempo(E);
		textoMESTLI(E);
		textoLetras(E);
		 
		mostrar_texto();
		  
		 //colision-----------
		if(validacion==40 && mapa[posZ][posX]==13)
		{
			puntos+=5, validacion++, lM=-30, palabra[0]='M';
		}
		if(validacion==41 && mapa[posZ][posX]==17)
		{
			puntos+=5, validacion++, lE=-30,palabra[1]='E';
		}
		if(validacion==42 && mapa[posZ][posX]==14)
		{
			puntos+=5, validacion++,lS=-30,palabra[2]='S';
		}
		if(validacion==43 && mapa[posZ][posX]==6)
		{
			puntos+=5, validacion++, lT=-30, palabra[3]='T';
		}
		if(validacion==44 && mapa[posZ][posX]==7)
		{
			puntos+=5, validacion++,lL=-30,palabra[4]='L';
		}
		if(validacion==45 && mapa[posZ][posX]==12)
		{
			puntos+=5, validacion++;
		}
		if(validacion==46)
		{
			rc=17;
			lM=0,lE=0,lS=0, lT=0, lL=0;
			limpiar_Arreglo();
		}	
		gluLookAt(camX,camY,camZ,0,0,0,camX,camY+1,camZ);
		glLightfv(GL_LIGHT0, GL_POSITION, light_position);
		dibujaMapa9();
		glutSwapBuffers();
	}
			
	//-------------------------------FIIINNN!!!----------
    
    if (rc==17)//mostramos la puntuacion final y el numero de vidas
	{
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glLoadIdentity();
		SDL_PauseAudio(1);
		textoFinPuntos(E);
		textoFinFelicidades(E);
		if(camY>minCamY)
		{
			camY-=300;
		}
		gluLookAt(camX,camY,camZ,0,0,0,camX,camY+1,camZ);
		glLightfv(GL_LIGHT0, GL_POSITION, light_position);
		glutSwapBuffers();
	}
      
   
}

void init() 
{
    glClearColor(0,0,0,0);
    camX = light_position[0] = 0.0f,camY = light_position[1] = 60.0f, camZ = light_position[2] =120.0f;
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);

    glEnable(GL_LIGHT0);
    glEnable(GL_NORMALIZE);
    glEnable(GL_COLOR_MATERIAL);
    glEnable(GL_CULL_FACE);
    glEnable(GL_LIGHTING);

    glLightfv(GL_LIGHT0, GL_SPOT_DIRECTION,light_spot_dir);
    glLightfv(GL_LIGHT0, GL_AMBIENT,  light_ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE,  light_diffuse);
    glLightfv(GL_LIGHT0, GL_LINEAR_ATTENUATION, light_attenuation);
    glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);
    glLightfv(GL_LIGHT0, GL_POSITION, light_position);
}
void moverCubo(int direccion)
{
	int j;
    switch(direccion){
        case MOV_ARRIBA://Arriba
            if(esValido(posX,posZ-1) && mapa[posZ-1][posX]!=1)
            {
                zActual-=20;
                display();
                posZ--;
            }
            break;
        case MOV_ABAJO://Abajo
            if(esValido(posX,posZ+1) && mapa[posZ+1][posX]!=1)
            {
                zActual+=20;
                display();
                posZ++;
            }
            break;
        case MOV_IZQUIERDA://Izquierda
            if(esValido(posX-1,posZ) && mapa[posZ][posX-1]!=1)
            {
                xActual-=20;
                display();
                posX--;
            }
            break;
        case MOV_DERECHA://Derecha
            if(esValido(posX+1,posZ) && mapa[posZ][posX+1]!=1)
            {
				xActual+=20;
                display();
                posX++;
            }
            break;
    }
}

// Función para controlar teclas especiales
void specialKeys( int key, int x, int y )
{
    if (key == GLUT_KEY_RIGHT)
        moverCubo(MOV_DERECHA);

    else if (key == GLUT_KEY_LEFT)
        moverCubo(MOV_IZQUIERDA);

    else if (key == GLUT_KEY_UP)
        moverCubo(MOV_ARRIBA);

    else if (key == GLUT_KEY_DOWN)
         moverCubo(MOV_ABAJO);

    //  Solicitar actualización de visualización
    display();
}

// función que permite interactuar con la escena mediante el teclado
void keyboard(unsigned char key, int x, int y){
    float t;
    switch(key) 
    {
		// ROTAR CAMARA LA IZQUIERDA
		// MOVER CAMARA HACIA ARRIBA
		case '3':
		SDL_PauseAudio(0);
			if(camY<maxCamY)
			{
				camY+=300;
				light_position[1] += 2;
			}
			rc++;
			display();
			break;
		// MOVER CAMARA HACIA ABAJO
		case '4':
			//anguloCamaraX--;
			if(camY>minCamY)
			{
				camY-=2;
			}
			display();
			break;
		case 27:
			exit(0);
			break;
    }
}


void update(int value)
{
		
		//animacion lapiz
		flt--;
		if(flt==0)
		{
			flt=30;
		}
		
		//tiempo
		tiempo--;
		
		if(tiempo==0)
		{
			rc=17;
		}
			
		if(tiempo==-150)
		{
			exit(0);
		}
		glutPostRedisplay();
		glutTimerFunc(25, update, 0);
}

//Funcion para llamadaal audio
void my_audio_callback(void *userdata, Uint8 *stream, int len)
{
	if (audio_len ==0)
		return;

	len = ( len > audio_len ? audio_len : len );
	SDL_memcpy (stream, audio_pos, len); 					// simply copy from one buffer into the other
	SDL_MixAudio(stream, audio_pos, len, SDL_MIX_MAXVOLUME);// mix from one buffer into another

	audio_pos += len;
	audio_len -= len;
}

int main(int argc, char **argv){
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_DEPTH | GLUT_RGB);
    glutInitWindowPosition(50, 50);
    glutInitWindowSize(1200, 800);
    glutCreateWindow("Juego de palabras");
    parseCubos();
    init();
    glutDisplayFunc(display);
    glutTimerFunc(30, update, 0);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboard);
    glutSpecialFunc(specialKeys);
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
    
    //~ //Sonido
    if (SDL_Init(SDL_INIT_AUDIO) < 0)
			return 1;

		// local variables
		static Uint32 wav_length; // length of our sample
		static Uint8 *wav_buffer; // buffer containing our audio file
		static SDL_AudioSpec wav_spec; // the specs of our piece of music


		/* Load the WAV */
		// the specs, length and buffer of our wav are filled
		if( SDL_LoadWAV(RUTA_AUDIO, &wav_spec, &wav_buffer, &wav_length) == NULL ){
		  return 1;
		}
		// set the callback function
		wav_spec.callback = my_audio_callback;
		wav_spec.userdata = NULL;
		// set our global static variables
		audio_pos = wav_buffer; // copy sound buffer
		audio_len = wav_length; // copy file length

		/* Open the audio device */
		if ( SDL_OpenAudio(&wav_spec, NULL) < 0 ){
		  exit(-1);
		}

    glutMainLoop();
    return 0;
    
    SDL_FreeWAV(wav_buffer);
}
