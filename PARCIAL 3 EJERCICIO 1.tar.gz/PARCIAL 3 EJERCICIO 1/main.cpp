#include <iostream>
#include <GL/glut.h>
#include <SOIL/SOIL.h>
#include <GL/gl.h>
#include <GL/glu.h>

//Definimos variables
GLfloat X = 0.0f;
GLfloat Y = -7.5f;
GLfloat Zes = -2.5f;
//tiros
float tiro = 0.0f;

//variables de rotacion
double rotate_y=0;
double rotate_x=0;
double rotate_z=0;

double rotate_z2=0;
//variable para cambiar ecenario
int E;
//Variable para cambiar el color del dino
int color=0;

GLuint texture[0];

//funcion para manipular la ventana
void resize(int h, int w) {
	if (h == 0)
		h = 1;
	float proporcion = w * 1.0 / h;
	glMatrixMode(GL_PROJECTION);
	// Reseteando la Matrix
	glLoadIdentity();
	glViewport(0, 0, w, h);
    gluPerspective(90.0, proporcion, 1.0, 100.0);
    glMatrixMode(GL_MODELVIEW);
}

void TextoTiros(int E){
	
    char texto[32];
    sprintf(texto, "Tiros = %.0f", tiro);
    glColor3f(1, 1, 1);
    glRasterPos3f(0,5,-8);
    for(int i = 0; texto[i] != '\0'; i++)
    glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, texto[i]);
}

void pared(){
	  glPushMatrix();
	
	//textura
		texture[2] = SOIL_load_OGL_texture 
                     (
                "pared.jpg",
                SOIL_LOAD_AUTO,
                SOIL_CREATE_NEW_ID,
                SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
                     );

     //Dibujamos
        
        glEnable(GL_TEXTURE_2D);
	
		//ambiente-fondo
		glBindTexture(GL_TEXTURE_2D, texture[0]);
		glBegin(GL_POLYGON);
		glNormal3f( 0.0f, 0.0f, 1.0f);
        glTexCoord2f(0.0f, 0.0f); glVertex3f(-30.0f, 0.0f, -20.5f);
        glTexCoord2f(1.0f, 0.0f); glVertex3f( -30.0f, 30.0f, -20.5f);
        glTexCoord2f(10.0f, 100.0f); glVertex3f( 30.0f,  30.f, -20.5f);
        glTexCoord2f(0.0f, 10.0f); glVertex3f(30.0f,  0.0f, -20.5f);
        glEnd();
           glPopMatrix();
	
	}
	
void fondo(){
	//texturas
		texture[0] = SOIL_load_OGL_texture // cargamos la imagen
                     (
                "fondo.jpg",
                SOIL_LOAD_AUTO,
                SOIL_CREATE_NEW_ID,
                SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
                     );

         //Dibujamos
        
        glEnable(GL_TEXTURE_2D);
	
		//ambiente-fondo
		glBindTexture(GL_TEXTURE_2D, texture[0]);
		glBegin(GL_POLYGON);
		glNormal3f( 0.0f, 0.0f, 1.0f);
        glTexCoord2f(0.0f, 0.0f); glVertex3f(-20.0f, -20.0f, -20.5f);
        glTexCoord2f(1.0f, 0.0f); glVertex3f( 20.0f, -20.0f, -20.5f);
        glTexCoord2f(1.0f, 1.0f); glVertex3f( 20.0f,  20.0f, -20.5f);
        glTexCoord2f(0.0f, 1.0f); glVertex3f(-20.0f,  20.0f, -20.5f);
        glEnd();
   
}

void pelota(float Xe, float Ye,float Ze)
{
	glTranslatef(Xe,Ye,Ze);
	glColor3f(1,1,95);
	glutSolidSphere(0.4,45.0,45.0);
    glEnd();

}

void piso()
{
	
	//texturas
		texture[0] = SOIL_load_OGL_texture // cargamos la imagen
                     (
                "Piso.jpg",
                SOIL_LOAD_AUTO,
                SOIL_CREATE_NEW_ID,
                SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
                     );

     //Dibujamos
        
        glEnable(GL_TEXTURE_2D);
	
		//ambiente-fondo
		glBindTexture(GL_TEXTURE_2D, texture[0]);
		glBegin(GL_POLYGON);
		glNormal3f( 0.0f, 0.0f, 1.0f);
        glTexCoord2f(0.0f, 0.0f); glVertex3f(-5.0f, -5.0f, -2.5f);
        glTexCoord2f(1.0f, 0.0f); glVertex3f( -5.0f, -5.0f, -20.5f);
        glTexCoord2f(1.0f, 1.0f); glVertex3f( 5.0f,  -5.0f, -20.5f);
        glTexCoord2f(0.0f, 1.0f); glVertex3f(5.0f,  -5.0f, -2.5f);
        glEnd();
   
	
	
}

void TableroBoliche()
{

			//texturas
		texture[1] = SOIL_load_OGL_texture // cargamos la imagen
                     (
                "negro.png",
                SOIL_LOAD_AUTO,
                SOIL_CREATE_NEW_ID,
                SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
                     );

     //Dibujamos
        
        glEnable(GL_TEXTURE_2D);
	
		//ambiente-fondo
		glBindTexture(GL_TEXTURE_2D, texture[1]);
		glBegin(GL_POLYGON);
		glNormal3f( 0.0f, 0.0f, 1.0f);
        glTexCoord2f(0.0f, 0.0f); glVertex3f(-5.0f, -5.0f, -20.5f);
        glTexCoord2f(1.0f, 0.0f); glVertex3f( -5.0f, 0.0f, -20.5f);
        glTexCoord2f(1.0f, 1.0f); glVertex3f( 5.0f,  0.f, -20.5f);
        glTexCoord2f(0.0f, 1.0f); glVertex3f(5.0f,  -5.0f, -20.5f);
        glEnd();
   
	
	
}

void pino1()
{	
	glPushMatrix();
	glRotatef( rotate_z, 0.0, 0.0, 1.0 );
	
		         
		 //~ glTranslatef(pX,pY,pZ);
		
			//texturas
		texture[0] = SOIL_load_OGL_texture // cargamos la imagen
                     (
                "pinos.png",
                SOIL_LOAD_AUTO,
                SOIL_CREATE_NEW_ID,
                SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
                     );

       //Dibujamos

        glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D, texture[0]);
		glBegin(GL_POLYGON);
		glNormal3f( 0.0f, 0.0f, 1.0f);
        glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.5f, -5.0f, -20.5f);
        glTexCoord2f(1.0f, 0.0f); glVertex3f( -0.5f, -5.0f, -20.5f);
        glTexCoord2f(1.0f, 1.0f); glVertex3f( -0.5f,  -2.f, -20.5f);
        glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.5f,  -2.0f, -20.5f);
        glEnd();
        
	 glPopMatrix();
}

void pino2()
{
	glPushMatrix();
	glRotatef( rotate_z2, 0.0, 0.0, 1.0 );
	
		
		
		texture[0] = SOIL_load_OGL_texture // cargamos la imagen
                     (
                "pinos.png",
                SOIL_LOAD_AUTO,
                SOIL_CREATE_NEW_ID,
                SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
                     );
	
	  glBegin(GL_POLYGON);
		glNormal3f( 0.0f, 0.0f, 1.0f);
        glTexCoord2f(0.0f, 0.0f); glVertex3f(0.5f, -5.0f, -20.5f);
        glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.5f, -5.0f, -20.5f);
        glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.5f,  -2.f, -20.5f);
        glTexCoord2f(0.0f, 1.0f); glVertex3f(0.5f,  -2.0f, -20.5f);
        glEnd();
        
          glPopMatrix();
}

void pino3()
{
	
		  glPushMatrix();
	
		texture[0] = SOIL_load_OGL_texture // cargamos la imagen
                     (
                "pinos.png",
                SOIL_LOAD_AUTO,
                SOIL_CREATE_NEW_ID,
                SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
                     );
	
	
		glBegin(GL_POLYGON);
		glNormal3f( 0.0f, 0.0f, 1.0f);
        glTexCoord2f(0.0f, 0.0f); glVertex3f( -3.0f, -5.0f, -20.5f);
        glTexCoord2f(1.0f, 0.0f); glVertex3f( -2.0f, -5.0f, -20.5f);
        glTexCoord2f(1.0f, 1.0f); glVertex3f( -2.0f,  -2.f, -20.5f);
        glTexCoord2f(0.0f, 1.0f); glVertex3f( -3.0f,  -2.0f, -20.5f);
        glEnd();
        
          glPopMatrix();
}

void pino4()
{
	  glPushMatrix();
	
	texture[0] = SOIL_load_OGL_texture // cargamos la imagen
                     (
                "pinos.png",
                SOIL_LOAD_AUTO,
                SOIL_CREATE_NEW_ID,
                SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
                     );
	
	
	glBegin(GL_POLYGON);
		glNormal3f( 0.0f, 0.0f, 1.0f);
        glTexCoord2f(0.0f, 0.0f); glVertex3f( 3.5f, -5.0f, -20.5f);
        glTexCoord2f(1.0f, 0.0f); glVertex3f( 2.5f, -5.0f, -20.5f);
        glTexCoord2f(1.0f, 1.0f); glVertex3f( 2.5f,  -2.f, -20.5f);
        glTexCoord2f(0.0f, 1.0f); glVertex3f( 3.5f,  -2.0f, -20.5f);
        glEnd();
        
          glPopMatrix();
}
void salto_caida(void)
{
	if(Zes>=-20.1)
	
	{
		Zes=-2.5;
	}
			
 glutPostRedisplay();
}


static void display(void)
{
		
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        glLoadIdentity();
		
		fondo();
		piso();
		TableroBoliche();
		glDisable(GL_TEXTURE_2D);
	    pared();
		pino1();
		pino2();
		pino3();
		pino4();
	  glEnd();
	  TextoTiros(E);
	  pelota(0,-2,Zes);
	      glEnd();
		
	// COLISION
	if(Zes<=-10)
	{
		
	rotate_z2=-30;
	rotate_z=60;
			
	}	
	
	//TIROS CONTADOR
	if(tiro==6)
	{
		tiro=0;
	}
		
		
		
        glFlush();
  glutSwapBuffers();
		
}

// Función para controlar teclas normales del teclado.
void keyboard(unsigned char key, int x, int y)
{    
    switch (key)
    {
    case '1':
        Zes =-2.5;
        tiro += 1.0;
        
        break;
  
  case 'W':
        Zes =-2.5;
        break;
  
    case 27:
        exit(0);//exit
    }
    glutPostRedisplay();
}

void update(int value)
{
		if(Zes<=-1.5)
		{
		Zes-=0.1;
		}
		
		if(Zes<=-15)
		{
			
		Zes=0.0;
		rotate_z =0; 
        rotate_z2=0;
        tiro+=1;
			
		}
			
		glutPostRedisplay();
		glutTimerFunc(25, update, 0);
}


int main(int argc, char **argv)
{
        glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
        glutInit(&argc, argv);
        glutInitWindowSize(700, 700);
        glutCreateWindow(".:   PARCIAL 3 EJERCICIO 1 : .");
        glutReshapeFunc(resize);
        glutKeyboardFunc(keyboard);
        glutDisplayFunc(display);      
        glutTimerFunc(30, update, 0);
        glEnable(GL_TEXTURE_2D);
        glShadeModel(GL_SMOOTH);
        glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
        glClearDepth(1.0f);
        glEnable(GL_DEPTH_TEST);
        glDepthFunc(GL_LEQUAL);
        glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
        glutMainLoop();
}
